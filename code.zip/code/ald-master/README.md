# ald

Automatic Locality Determination (ALD) is published in PlosCB 2011 : http://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1002219

Description for testScript.html has some short description on how to use this code using examples that are written in testScript.m. 
