function [logEv,khat,param,rep] = creatingLLspace(datastruct,paramSM8)

lfun = @(p)gradLogEv_ALDs(p, datastruct);

prs=paramSM8(:,2);
vPhi=-0.99:0.03:0.99;
vMu1=0:1:25;
vMu2=[4 9 14];

for ii=1:length(vMu2)
    ii
    for xx=1:length(vMu1)
        for yy=1:length(vPhi)
            prsTemp=prs;
            prsTemp(2)=vMu1(xx);
            prsTemp(3)=vMu2(ii);
            prsTemp(6)=vPhi(yy);
            [logEv(xx,yy,ii),df,ddf,khat(xx,yy,ii).data,PostCov, Cprior] = lfun(prsTemp);
        end
    end
end

param.vPhi=vPhi;
param.vMu1=vMu1;
param.vMu2=vMu2;

[rep(1).logEv,df,ddf,rep(1).khat,PostCov, Cprior] = lfun(paramSM8(:,1));
[rep(2).logEv,df,ddf,rep(2).khat,PostCov, Cprior] = lfun(paramSM8(:,2));



