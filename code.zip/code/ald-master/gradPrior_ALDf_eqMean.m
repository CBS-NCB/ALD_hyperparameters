function [f, df, khat, LL,Cprior,CpriorFull,term1,term2] = gradPrior_ALDf_eqMean(prs, datastruct)
assert(length(prs)==6);
prs_new = zeros(7,1);
prs_new(1:5) = prs(1:5);
prs_new(6) = prs(5);
prs_new(7) = prs(6);
prs = prs_new;
%
%--------------------------------------------------------------------------
% gradPrior_ALDf: compute gradients of ALDs prior covariance matrix
%--------------------------------------------------------------------------
% 
% INPUT ARGUMENTS:
%   prs = initial value of hyperparameters of ALDf prior cov. mat.
%   datastruct - has data info such as XX, XY, YY, stimulus dimension
%
% OUTPUT ARGUMENTS:
%   f - maximum evidence given data
%   df - df/dtheta at f = f_max
%   khat - estimate of kernel
%   LL - posterior covariance at f = f_max
%
%  (Updated: 23/12/2011 Mijung Park) 

%  Unpack the data information:
XX = datastruct.xxf;
XY = datastruct.xyf;
YY = datastruct.yy;
nsamps = datastruct.nstim;
ndims = datastruct.ndims;

% Unpack params
nsevar = prs(1);
prs = prs(2:end); % Hyper-params, except noise variance

% Check total dimension of the filter
leng_ndims = length(ndims);

%% form Cprior based on coordinate dimension

switch leng_ndims
    case (1)
        
        nx = ndims(1);
        
        M = prs(1); % unpack params
        vmu = prs(2);
        ovsc = prs(3);
        
        fx = FFTaxis(nx); % coordinates in Fourier domain
        w = fx(:);
        muvec = vmu.*ones(1, length(w));
        
    case (2)
        
        ny = ndims(1);
        nx = ndims(2);
        
        M = [prs(1) prs(2); prs(2) prs(3)]; % unpack params
        vmu = [prs(4); prs(5)];
        ovsc = prs(6);
        
        [fy, fx] =  FFT2axis(ny,nx);  % coordinates in Fourier domain
        w = [fy(:) fx(:)];
        muvec = repmat(vmu, 1, length(w));
        
    case (3)
        
        nt = ndims(1);
        ny = ndims(2);
        nx = ndims(3);
        
        M = [prs(1) prs(2) prs(3); prs(2) prs(4) prs(5); prs(3) prs(5) prs(6)]; % unpack params
        vmu = [prs(7); prs(8); prs(9)];
        ovsc = prs(10);
        
        
        [ft, fy, fx] =  FFT3axis(nt, ny, nx); % coordinates in Fourier domain
        w = [ft(:) fy(:) fx(:)];
        muvec = repmat(vmu, 1, length(w));
        
    otherwise
        
        disp('this dimension is not applicable');
        
end

% M1=[1 1; 1 1]
% M2=[-1 .1; .1 -1]
% M3=[1 -1; -1 1]
% M4=[-1 -1; -1 -1]
% absMw1 = abs(M1*w');
% absMw2 = abs(M2*w');
% absMw3 = abs(M3*w');
% absMw4 = abs(M4*w');
% 
% figure
% subplot(2,2,1)
% imagesc(reshape(absMw1(1,:),[24 24]))
% subplot(2,2,2)
% imagesc(reshape(absMw2(1,:),[24 24]))
% subplot(2,2,3)
% imagesc(reshape(absMw3(1,:),[24 24]))
% subplot(2,2,4)
% imagesc(reshape(absMw4(1,:),[24 24]))

% M=[0.4 -0.1; -0.1 0.2]
% M2=[-0.4 -0.1; -0.1 0.2]
% absMw1 = abs(M*w');
% absMw2 = abs(M2*w');
% 
% figure
% subplot(2,2,1)
% imagesc(reshape(absMw1(1,:),[24 24]))
% subplot(2,2,2)
% imagesc(reshape(absMw1(2,:),[24 24]))
% 
% subplot(2,2,3)
% % imagesc(reshape(absMw(1,:),[24 24]))
% imagesc(reshape(absMw2(1,:),[24 24]))
% subplot(2,2,4)
% % imagesc(reshape(absMw(1,:),[24 24]))
% imagesc(reshape(absMw2(2,:),[24 24]))

% 
% M=[-1 0; 0 1];
% 
absMw = abs(M*w');
sign_absMw = sign(M*w')';
X2 = (absMw - muvec)';
cdiag = exp(-.5*sum(X2.*X2,2)- ovsc); % diag of ALDf prior cov. mat.

svMin = 1e-6; % singular value threshold for eliminating dimensions  to make code fast
svthresh = max(cdiag)*svMin;

% 
% 
% smw1=absMw(1,:);
% smw2=absMw(2,:);
% 
% figure
% subplot(2,2,1)
% imagesc(reshape(smw1,[24 24]))
% 
% subplot(2,2,2)
% imagesc(reshape(smw2,[24 24]))
% 
% subplot(2,2,3)
% imagesc(fftshift(reshape(cdiag,[24 24])))


% 
% figure
% subplot(1,2,1)
% imagesc(reshape(w(:,1),[24 24]))
% colorbar
% subplot(1,2,2)
% % imagesc(reshape(absMw(1,:),[24 24]))
% imagesc(reshape(w(:,2),[24 24]))
% imagesc(reshape(absMw(1,:),[24 24]))

%forcing the prior to be centered BEFORE pruning
% figure(100) 
% subplot(1,2,1)
% imagesc(fliplr(flipud(reshape(cdiag,[24 24]))))
% 
% diag24=reshape(cdiag,[24 24]);
% template=diag24(1:12,1:12);
% diagNew=diag24;
% diagNew(13:24,1:12)=flipud(template);
% diagNew(1:12,13:24)=fliplr(template);
% diagNew(13:24,13:24)=flipud(fliplr(template));


% cdiag=diagNew(:);

% subplot(1,2,2)
% imagesc(fliplr(flipud(reshape(cdiag,[24 24]))))

% prune data based on frequency sparsity
cdiagFull=cdiag;
if min(cdiag)>svthresh
    iikeep = true(length(cdiag), 1);
else
    iikeep = (cdiag>=svthresh);
    X2 = X2(iikeep, :);
    w = w(iikeep, :);
    sign_absMw = sign_absMw(iikeep, :);
    cdiag = cdiag(iikeep);
end


Cprior = diag(cdiag);
CpriorFull = diag(cdiagFull);


%% evaluate log-evidence & compute 1st/2nd Derivatives w.r.t. noise variance

[f, khat, LL, df1, ddf1, LLinvC,diag_LLXXLLinvC,term1,term2] = gradLogEv(Cprior, abs(nsevar),XX(iikeep, iikeep),XY(iikeep),YY,nsamps);
f = -f;

%% Gradients of Cprior w.r.t each hyperparam

numb_params = length(prs); % alpha, mu, gam, phi
leng_keep = sum(iikeep);
I = ones(leng_keep,1);

cGrad = zeros(leng_keep, numb_params); % cGrad = dC/dtheta   I = ones(leng_keep,1);

% dM/dm_i
if leng_ndims==1
    nM = leng_ndims;
    der_absMw = zeros(leng_keep, leng_ndims, nM);
    der_absMw(:,:,1) = sign_absMw.*w;
else
    nM = leng_ndims + nchoosek(leng_ndims, 2);
    der_absMw = zeros(leng_keep, leng_ndims, nM);
    if leng_ndims == 2
        der_absMw(:,:,1) = sign_absMw.*[w(:,1) zeros(leng_keep,1)];
        der_absMw(:,:,2) = sign_absMw.*[w(:,2) w(:,1)];
        der_absMw(:,:,3) = sign_absMw.*[zeros(leng_keep,1) w(:,2)];
    else %leng_ndims ==3
        der_absMw(:,:,1) = sign_absMw.*[w(:,1) zeros(leng_keep,2)];
        der_absMw(:,:,2) = sign_absMw.*[w(:,2) w(:,1) zeros(leng_keep,1)];
        der_absMw(:,:,3) = sign_absMw.*[w(:,3) zeros(leng_keep,1) w(:,1)];
        der_absMw(:,:,4) = sign_absMw.*[zeros(leng_keep,1) w(:,2) zeros(leng_keep,1)];
        der_absMw(:,:,5) = sign_absMw.*[zeros(leng_keep,1) w(:,3) w(:,2)];
        der_absMw(:,:,6) = sign_absMw.*[zeros(leng_keep,2) w(:,3)];
    end
end

% gradients wrt M
for i=1:nM
    cGrad(:,i) = - sum(X2.*der_absMw(:,:,i),2);
end

% gradients wrt mu
der_mu = zeros(leng_keep, leng_ndims, leng_ndims);

for i=1:leng_ndims
    der_mu(:,i,i) = - I;
    cGrad(:,nM+i) =  - sum(X2.*der_mu(:, :, i), 2);
end

% gradients wrt overall scale
cGrad(:,end) = - I;

%% Gradients of evidence w.r.t. hyperparams

Ivec = ones(leng_keep, 1);
diagTrm = Ivec - diag(LLinvC) - sum((khat*(XY(iikeep))').*transpose(LLinvC), 2)./nsevar;
dfdthet = - .5*cGrad'*diagTrm;  % 0.5* Tr(C - Lambda - k*k')*dCinv/dtheta);
df = -[df1; dfdthet];
df = real(df);

df(6)=[];
%% project back to the original space

nx = size(XX,1);

khatreduced = khat; % khat (posterior mean)
khat = zeros(nx, 1);
khat(iikeep) = khatreduced;

Lmat = zeros(nx, nx); % LL (posterior covariance)
Lmat(iikeep, iikeep) = LL;
LL = Lmat;


