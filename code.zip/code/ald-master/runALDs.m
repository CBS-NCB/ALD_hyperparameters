function [khat, logEv, prs, PostCov, Cprior,cdiag1,cdiag2,termsFitting] = runALDs(prs0, datastruct, opts1,plotFlag)
%
%--------------------------------------------------------------------------
% runALDs.m: runs Empirical Bayes with ALDs prior using fmincon
%--------------------------------------------------------------------------
% 
% INPUT ARGUMENTS:
%   prs0 = initial value of hyperparameters of ALDs prior cov. mat.
%   datastruct - has data info such as XX, XY, YY, stimulus dimension
%   opts1 - (optional) options stucture:  'maxiter' and 'tol' etc.
%
% OUTPUT ARGUMENTS:
%   khat - ridge regression RF estimate 
%   logEv - log-evidence at ALDs solution
%   prs - estimate for hyperparameters
%   PostCov - posterior covariance at ALDs solution
%
%  (Updated: 23/12/2011 Mijung Park) 

ndims = datastruct.ndims;
leng_ndims = length(ndims);

% set bounds on hyperparameters
noiseRange = [1e-3, 1e3];
muRange = [-1+zeros(leng_ndims,1), ndims];
gammaRange = [2.0*ones(leng_ndims,1), ndims/2];
oscaleRange = [-20, 20];

if leng_ndims ==1
    LB = [noiseRange(1); muRange(:,1); gammaRange(:,1);oscaleRange(1)]; 
    UB = [noiseRange(2); muRange(:,2); gammaRange(:,2);oscaleRange(2)];
else 
    phiRange = [.5.*ones(nchoosek(leng_ndims,2),1), .5.*ones(nchoosek(leng_ndims,2),1)];
    
    if datastruct.twoLocationsFlag==1
        LB = [noiseRange(1); muRange(:,1); muRange(:,1); gammaRange(:,1); gammaRange(:,1); phiRange(:,1); phiRange(:,1); oscaleRange(1)]; 
        UB = [noiseRange(2); muRange(:,2); muRange(:,2); gammaRange(:,2); gammaRange(:,2); phiRange(:,2); phiRange(:,2); oscaleRange(2)]; 
    else
        LB = [noiseRange(1); muRange(:,1); gammaRange(:,1); phiRange(:,1);oscaleRange(1)]; 
        UB = [noiseRange(2); muRange(:,2); gammaRange(:,2); phiRange(:,2);oscaleRange(2)]; 
    end
end

% FIXED PARAMETER VALUES:
%%thetaS_LB_UB = [ 0.001; 15; 12; 7; 7; 0.5; 8];
%LB = [ 0.001; 15; 12; 7; 7; 0.5; 8];
%UB = [ 0.001; 15; 12; 7; 7; 0.5; 8];
LB = [ 0.001; 15.09; 10.39; 6.15; 6.04; 0.5; 8.66];
UB = [ 0.001; 15.09; 10.39; 6.15; 6.04; 0.5; 8.66];

lfun = @(p)gradLogEv_ALDs(p, datastruct);

% ------ Optimize evidence --------------------------------------
prs = fmincon(lfun,prs0,[],[],[],[],LB,UB,[],opts1);

% ------ compute filter and posterior variance at maximizer --------------
[logEv,df,ddf,khat,PostCov, Cprior,cdiag1,cdiag2,trm1,trm2] = lfun(prs);
[logEv0,df0,ddf0,khat0,PostCov0, Cprior0,cdiag01,cdiag02,trm01,trm02] = lfun(prs0);
termsFitting=[trm01 trm1 trm02 trm2];


if plotFlag==1
    beforeNafterFitting(logEv0,df0,ddf0,khat0,PostCov0,Cprior0,logEv,df,ddf,khat,PostCov, Cprior)
end

fprintf('ALDs is terminated');
