% ALD test on some of our data

%% example (by Park,Pillow)
clear;
clc;

nstim = 1000; % number of stimuli
nsevar = 1; %  noise variance

% true filter with spatial dimension nx, difference of two Gaussians.
filterdims = 100;
ktrue = genkTrue(filterdims); % ktrue in 1d
% plot(ktrue);

% 1. generate stimuli (choose either 1/f stimuli or white noise stimuli)
whichstim = 1; % white noise stimuli, if you want 1/f stimuli, set "whichstim=1"
Stimuli = genStim(filterdims, nstim, whichstim);

% 2. generate noisy response: training & test data
ytraining = Stimuli.xTraining*ktrue + randn(nstim,1)*nsevar; % training data
% ytest = Stimuli.xTest*ktrue + randn(nstim,1)*nsevar; % test data (for cross-validation)

% 3. ALDs,f,sf, ML, and ridge regression
nkt = 1;
[khatALD kridge] = runALD(Stimuli.xTraining, ytraining, filterdims, nkt);

figure(1);
plot([ktrue, kridge, khatALD.khatSF]);
legend('true', 'ridge', 'ALDsf');

%% 1. fit our ridge regression model, with just one kernel -- eye; 
%% 2. fit their model to our data, with just one kernel -- eye; compare to 1
%% 3. find how to deal with three distinct inputs (can reuse their 3D kernel?)

%% 
load('H:\Data for ALD\m15100_model.mat');
tensorfname = 'H:\Data for ALD\m15100_tensor_small_no1s_noMv_noBlnk.dat';
m = memmapfile(tensorfname,'Format','single');
tensor = reshape(m.Data,[],250,length(model.data.validtrials));

model.krnsizes = 140;
model.data.inputs = model.data.inputs(1);
%% 

[model.regr.X,model.regr.trialind]=prepPredictors(model.data.inputs,model.krnsizes,model.data.trial_lgt);

%% 

model_ridge=model;model_ridge.roi=ones(size(tensor,1),1);
loadparams = false;
model_ridge.regr.thistile = 1:size(tensor,1);%but this way all tiles are fitted individually
model_ridge.regr.params = [];
model_ridge=fitTileKern(model_ridge,tensor,'onetile','ridge','cv',loadparams); 

%% 
targetf0 = squeeze(tensor(59,:,:));
alltarg=prepTargets(model_ridge.regr.trialind,targetf0,model_ridge.data.trial_lgt);

nkt = 1;
[khatALD kridge] = runALD(model_ridge.regr.X, alltarg, [75;75], nkt);
%% 

%% 1. ALDs

% options: ALDs uses trust-region algorithm with analytic gradients and Hessians
opts1 = optimset('display', 'iter', 'gradobj', 'on','tolfun',1e-8, 'TolX', 1e-8, 'TolCon', 1e-8, 'MaxIter', 1e3, 'MaxFunEval', 3*1e3);

% Find good initial values
InitialValues = NgridInit_pixel(datastruct.ndims, nsevar, ovsc, kRidge); % make a coarse grid
prs_p = compGriddedLE(@gradLogEv_ALDs, InitialValues, datastruct); % evaluate evidence on the grid

[khatALD.khatS, khatALD.evidS, khatALD.thetaS, khatALD.postcovS] = runALDs(prs_p, datastruct, opts1);

