function [khat,logEv,prs, PostCov, LB, UB, CpriorFull,termsFitting] = runALDf(prs0, isotropicFlag, datastruct, opts)%, eqMeanFlag)
%
%--------------------------------------------------------------------------
% runALDf.m: runs Empirical Bayes with ALDf prior (including symmetric M and mu)
%--------------------------------------------------------------------------
% 
% INPUT ARGUMENTS:
%   prs0 = initial value of hyperparameters of ALDs prior cov. mat.
%   datastruct - has data info such as XX, XY, YY, stimulus dimension
%   opts1 - (optional) options stucture:  'maxiter' and 'tol' etc.
%
% OUTPUT ARGUMENTS:
%   khat - ridge regression RF estimate 
%   logEv - log-evidence at ALDf solution
%   prs - estimate for hyperparameters
%   PostCov - posterior covariance at ALDf solution
%
%  (Updated: 23/12/2011 Mijung Park) 

ndims = datastruct.ndims;
leng_ndims = length(ndims);

% set bounds on estimated parameters
noiseRange = [1e-3, 1e3];
m = 3*[-ones(leng_ndims, 1), ones(leng_ndims,1)];
mu = [-ndims/2, ndims/2];
oscaleRange = [0, 20];

if leng_ndims ==1
    LB = [noiseRange(1); m(1); mu(1);oscaleRange(1)]; 
    UB = [noiseRange(2); m(2); mu(2);oscaleRange(2)];
elseif leng_ndims ==2
    LB = [noiseRange(1); m(:,1); m(1,1); mu(:,1); oscaleRange(1)]; 
    UB = [noiseRange(2); m(:,2); m(1,2); mu(:,2); oscaleRange(2)];
    if isotropicFlag==1
        LB(3)=0;
        UB(3)=0;
    end
%     if eqMeanFlag==1
%         LB = [noiseRange(1); m(:,1); m(1,1); mu(1,1); oscaleRange(1)]; 
%         UB = [noiseRange(2); m(:,2); m(1,2); mu(1,2); oscaleRange(2)];
%     end
else % 3d
    LB = [noiseRange(1); m(:,1); m(:,1); mu(:,1); oscaleRange(1)]; 
    UB = [noiseRange(2); m(:,2); m(:,2); mu(:,2); oscaleRange(2)];    
end

% FIXED PARAMETER VALUES:
%%thetaF_LB_UB = [ 0.001; X;  X;  X; 1;  1; 13];
% LB(1) = 0.001; UB(1) = 0.001; 
% LB(5) = 1; UB(5) = 1;
% LB(6) = 1; UB(6) = 1;
% LB(7) = 13; UB(7) = 13;
% % %
LB(1) = 0.001; UB(1) = 0.001; 
LB(5) = -0.15; UB(5) = -0.15;
LB(6) = 0.53; UB(6) = 0.53;
LB(7) = 12.24; UB(7) = 12.24;


lfun = @(p)gradPrior_ALDf(p, datastruct);
%lfun = @(p) gradPrior_ALDf_eqMean(p, datastruct);

% ------ Optimize evidence --------------------------------------
% if eqMeanFlag==1,
%     prs0(6)=[];
% end
prs = fmincon(lfun,prs0,[],[],[],[],LB,UB,[],opts);

[f, df, khat, LL, Cprior, CpriorFull,term01,term02] = gradPrior_ALDf(prs0, datastruct);
[f, df, khat, LL, Cprior, CpriorFull,term1,term2] = gradPrior_ALDf(prs, datastruct);
%[f, df, khat, LL, Cprior, CpriorFull,term01,term02] = gradPrior_ALDf_eqMean(prs0, datastruct);
%[f, df, khat, LL, Cprior, CpriorFull,term1,term2] = gradPrior_ALDf_eqMean(prs, datastruct);
termsFitting=[term01 term1 term02 term2];

% ------ compute filter and posterior variance at maximizer --------------
[logEv,df, kh, PostCov] = lfun(prs);

if leng_ndims==1
    M = FFTmatrix(ndims);
    khat_cc = M'*kh;
elseif leng_ndims==2
    nt = ndims(1);
    nx = ndims(2);
    M = FFT2matrix(nt, nx);
    khat_cc = reshape(M'*kh, nt, nx);
else % if k is 3 dim.
    nt = ndims(1);
    ny = ndims(2);
    nx = ndims(3);
    BB = FFT3matrix(nt, ny, nx);
    khat_cc = permute(reshape(BB'*kh(:), nt, ny, nx), [2 3 1]);
end

khat = real(khat_cc); % to remove numerical errors (small imaginary parts)

fprintf('ALDf is terminated');