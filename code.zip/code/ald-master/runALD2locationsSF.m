function [khatALD, kRidge] = runALD2locationsSF(x, y, spatialdims, nkt)


%% Data structure of sufficient statistics from raw data

datastruct = formDataStruct(x, y, nkt, spatialdims);
datastruct.twoLocationsFlag=0;

numb_dims = length(datastruct.ndims); 

%% Ridge regression for initialization

opts0.maxiter = 1000;  % max number of iterations
opts0.tol = 1e-6;  % stopping tolerance
lam0 = 10;  % Initial ratio of nsevar to prior var (ie, nsevar*alpha)
% ovsc: overall scale, nasevar: noise variance
[kRidge, ovsc ,nsevar]  =  runRidge(lam0, datastruct, opts0);

%% 1. ALDs

opts1 = optimset('display', 'iter', 'gradobj', 'on','tolfun',1e-8, 'TolX', 1e-8, 'TolCon', 1e-8, 'MaxIter', 1e3, 'MaxFunEval', 1e3);

% Find good initial values
try InitialValues = NgridInit_pixel(datastruct.ndims, nsevar, ovsc, kRidge); % make a coarse grid
catch% try recalculating the initial values?
    [kRidge, ovsc ,nsevar]  =  runRidge(lam0, datastruct, opts0);
    InitialValues = NgridInit_pixel(datastruct.ndims, nsevar, ovsc, kRidge); % make a coarse grid
end
prs_p = compGriddedLE(@gradLogEv_ALDs, InitialValues, datastruct); % evaluate evidence on the grid

% easy solution for now, to be improved!
datastruct.twoLocationsFlag=1;

if datastruct.twoLocationsFlag==1
    prs_p=[prs_p(1) prs_p(2) prs_p(3) prs_p(2) prs_p(3) prs_p(4) prs_p(5) prs_p(4) prs_p(5) prs_p(6) prs_p(6) prs_p(7)]';
end

[khatALD.khatS, khatALD.evidS, khatALD.thetaS, khatALD.postcovS, khatALD.CpriorS, khatALD.termsFittingS] = runALDs(prs_p, datastruct, opts1,0);
khatALD.thetaS0=prs_p;



%% 2. ALDf

% ALDf and ALDsf uses active-set algorithm with analytic gradients
%opts2 = optimset('display', 'iter', 'gradobj', 'on', 'algorithm','active-set','tolfun',1e-8, 'TolX', 1e-8, 'TolCon', 1e-8, 'MaxIter', 1e3, 'MaxFunEval', 3*1e3);
opts2 = optimset('display', 'iter', 'gradobj', 'on', 'algorithm','active-set','tolfun',1e-8, 'TolX', 1e-8, 'TolCon', 1e-8, 'MaxIter', 5e2, 'MaxFunEval', 5e2);

% Initialize diagonal of M
InitialValues = NgridInit_freq_diag(datastruct.ndims, nsevar, khatALD.thetaS(end)); % make a coarse grid
prs_f = compGriddedLE(@gradPrior_ALDf_diag, InitialValues, datastruct); % evaluate evidence on the grid
% Run ALDf using diagonal M and zero mean to initialize M
[khatALD.khatFdiag, khatALD.evidFdiag, khatALD.thetaFdiag, khatALD.postcovFdiag] = runALDf_diag(prs_f, datastruct, opts2);

mu_init = zeros(numb_dims,1);
if numb_dims==1
    offDiagTrm = [];
else
    offDiagTrm = numb_dims*(numb_dims-1)/2;
end
prsALDf_init = [khatALD.thetaFdiag(1:end-1); 0.1*ones(offDiagTrm,1); mu_init; khatALD.thetaFdiag(end)];

[khatALD.khatF, khatALD.evidF, khatALD.thetaF, khatALD.postcovF , UB,LB, khatALD.CpriorF,khatALD.termsFittingF] = runALDf(prsALDf_init, datastruct, opts2);
khatALD.thetaF0=prsALDf_init;

%% 3. ALDsf

% choose min. value among the overall scales of ALDs and ALDf prior cov.
% to optimize from a large Gaussian
ovsc_sf = min(khatALD.thetaS(end), khatALD.thetaF(end));

% set other initial values to those estimated in ALDs and ALDf
pFixed=[khatALD.thetaS];
prsALDsf_init = [khatALD.thetaF(2:end-1)];
[khatALD.khatSF, khatALD.evidSF, khatALD.thetaSF, khatALD.postcovSF, khatALD.CpriorSF, khatALD.CpriorSFF,khatALD.CpriorSFS,khatALD.CpriorSFBB] =  runALDsfAA(prsALDsf_init, diag(khatALD.CpriorS), diag(khatALD.CpriorF), pFixed, datastruct, opts2);

% prsALDsf_init = [khatALD.thetaS(1:end-1); khatALD.thetaF(2:end-1); abs(ovsc_sf)/10];
% [khatALD.khatSF, khatALD.evidSF, khatALD.thetaSF, khatALD.postcovSF, khatALD.CpriorSF, khatALD.CpriorSFF,khatALD.CpriorSFS,khatALD.CpriorSFBB] =  runALDsf(prsALDsf_init, datastruct, opts2);
