% show saturation of M(N) to the values reported in the manuscript
% must compute an analog of bootstrap averages

%% 1. Load the simulation results.

%% 2. Remove M outliers, for an individual animal given all model fits

test = load("revision_sample_variation_10_20_tr_50_sz_5_an_5_fixed_all_but_M_2.mat", "tbl");
tbl = test.tbl;
tbl = rm_outliers(tbl);

%% 3. Fix the sampling size and create a table with bootstrap ids

sz = 5; % for sample_sizes = [50, 100, 200, 300, 396];
tbl_fix_sz = tbl(tbl(:,1)==sz,:);
tbl_fix_sz_iboot=group_rows_as_HB_samples(tbl_fix_sz);

%% 4. Plot the progression of M with sz change

mean_CI=compute_mean_CI_across_sizes_and_animals(tbl);

colors = {'b','r','m','g','k'}; 
param_id = 2; %M11=1;M12=2,M22=3
sample_sizes = [50, 100, 200, 300, 396];
figure,
for i=1:5,
    shadedErrorBar(sample_sizes,mean_CI.mean(:,i,param_id), mean_CI.CI(:,i,param_id),colors{i},0.5);
    hold on,
end

% get the mean values as in the manuscript for reference 
meanvals_manuscript = calc_manuscript_means();
for i=1:5,
    plot(sample_sizes([1,5]),meanvals_manuscript(i,param_id)*[1,1],strcat(colors{i},'--'))
    hold on,
end

set(gcf,'Color',[1, 1, 1]);
set(gca,"TickDir","out")
axis square;
xlabel("Sample size, trials")
if param_id==1,
    ylabel("M11 value")
    title("M11 value change with sample size")
elseif param_id==2,
    ylabel("M12 value")
    title("M12 value change with sample size")
elseif param_id==3,
    ylabel("M22 value")
    title("M22 value change with sample size")
end

%func_saveFig('D:\labserver6-personal\Andrea intern\final Code Interaction Kernel\figures\',[],150,[],'revision_M_vs_N',1,1,1);
%% 5. Scatter plots for fixed M: sz=1 and sz=5;

% make sure tbl_fix_sz_iboot is computed for sz=1
sz = 1;
tbl_fix_sz = tbl(tbl(:,1)==sz,:);
tbl_fix_sz_iboot=group_rows_as_HB_samples(tbl_fix_sz);

[rho_boot,pval_boot,meanvals_boot,true_Anids,meanvals_all,rho_all,pval_all]=calcCorrFromTable(tbl_fix_sz_iboot);
scatterplots_M_pCV(meanvals_boot, true_Anids)
title("Sample size 50 tr")

% make sure tbl_fix_sz_iboot is computed for sz=5
sz = 5;
tbl_fix_sz = tbl(tbl(:,1)==sz,:);
tbl_fix_sz_iboot=group_rows_as_HB_samples(tbl_fix_sz);

[rho_boot,pval_boot,meanvals_boot,true_Anids,meanvals_all,rho_all,pval_all]=calcCorrFromTable(tbl_fix_sz_iboot);
scatterplots_M_pCV(meanvals_boot, true_Anids)
title("Sample size 396 tr")

%% 6. compute pboot for correlations
% rho_boot columns: M11x12,11x22,12x22; M11,12,22 x pCV
disp(strcat('p-boot = ', num2str(sum(rho_boot<0)/size(rho_boot,1))))
disp(strcat("if 0, pboot is smaller than ", num2str(1/size(rho_boot,1))) )

%% 7. can compute pboot change for different sample sizes:
mean_rho_boot = [];
rho_boot_below_05 = [];
for sz = 1:5
    tbl_fix_sz = tbl(tbl(:,1)==sz,:);
    tbl_fix_sz_iboot=group_rows_as_HB_samples(tbl_fix_sz);
    [rho_boot,pval_boot,meanvals_boot,true_Anids,meanvals_all,rho_all,pval_all]=calcCorrFromTable(tbl_fix_sz_iboot);
    rho_boot_below_05 = [rho_boot_below_05; sum(rho_boot<0.5)/size(rho_boot,1)];
    mean_rho_boot = [mean_rho_boot; mean(rho_boot)];
end
disp(strcat('corr below 0.5 (frac. bootstraps):  p-boot = ', num2str(rho_boot_below_05)))
disp(strcat('corr below 0 (frac. bootstraps):  p-boot = ', num2str(mean_rho_boot)))

sample_sizes = [50, 100, 200, 300, 396];

figure, plot(sample_sizes,mean_rho_boot(:,4:6));
xlabel("Sample size, N trials");
ylabel("Mean corr(M,pCV)");
legend(["M11,pCV","M12,pCV","M22,pCV"]);
title("M-pCV correlation vs bootstrap sample size");
set(gcf, "Color",[1 1 1]);
set(gca, "TickDir","out");


figure, plot(sample_sizes,rho_boot_below_05(:,4:6));
xlabel("Sample size, N trials");
ylabel("Fraction bootstrap samples with corr(M,pCV)<0.5");
legend(["M11,pCV","M12,pCV","M22,pCV"]);
title("Weaker M-pCV correlation for small sample sizes");
set(gcf, "Color",[1 1 1]);
set(gca, "TickDir","out");
%% ALL FUNCTIONS

function tbl=rm_outliers(tbl)
    % exclude outliers from the HB table

    % assumes animal id column 3, parameter columns 5:8
    animal_col = 3;% "absolute" animal id
    param_cols = 5:8;% M11,M12,M22,pCV

    tbl_clean = [];
    unqan = unique( tbl(:,animal_col) );
    for i = 1:length(unqan),
        tbl_an = tbl(tbl(:,animal_col) == unqan(i), :);
        [~,i_excl] = rmoutliers(tbl_an(:,param_cols));
        tbl_an(i_excl,:) = [];
        tbl_clean = [tbl_clean; tbl_an];
    end
    tbl = tbl_clean;
end


function tbl_fix_sz_iboot=group_rows_as_HB_samples(tbl_fix_sz)
    % Insert a column of bootstrap ids in a bootstrap table with one-level
    % sampling. I.e. create sampling hierarchy post-hoc by grouping trials.
    % Emulates the HB sampling in which on every iBoot every animal has the
    % same chance to be sampled. 
    % Is used in Mxx(N) analysis, for a subtable corresponding to a fixed N.
    % A subtable like this will have 1st column with identical values (N),
    % which can be reused to store bootstrap group ids.

    % in tbl_fix_sz(:,2) animal ids go in blocks by animal, i.e.
    % 111..222..333 etc, so bootstrap ids in the created column have to run
    % from 1 to nBoot for every animal

    iBoot_step_trials = 15;% 15-20 is a typical number of model fits in HB after removing outliers for a mouse
    all_iBoot = [];% vector of all bootstrap group indices
    all_max_iBoot = [];% max bootstrap id for every animal
    iAn_col = 2;% column of 1..5 "relative" animal ids among those with sufficient data
    nAn = 5;
    for iAn = 1:nAn,
        total_iAn_tr=sum(tbl_fix_sz(:,iAn_col)==iAn);
        
        % total number of full iBoot chunks
        max_iBoot = floor(total_iAn_tr/iBoot_step_trials);
        a = reshape(1:max_iBoot,[],1);% bootstrap ids vector
        iBoot_iAn = reshape(repmat(a,1,iBoot_step_trials)',[],1);% repeat the ids to create a grouping
        iBoot_iAn = [iBoot_iAn; (max_iBoot+1)*ones(total_iAn_tr-length(iBoot_iAn),1)];
        
        all_iBoot = [all_iBoot;iBoot_iAn];
        all_max_iBoot = [all_max_iBoot; max_iBoot];
    end

    tbl_fix_sz_iboot = tbl_fix_sz;
    tbl_fix_sz_iboot(:,1) = all_iBoot;
    tbl_fix_sz_iboot = tbl_fix_sz_iboot(tbl_fix_sz_iboot(:,1)<=min(all_max_iBoot),:);% clipping to min(max(iBoot)) so that animals appear in all bootstraps

end


function mean_CI=compute_mean_CI_across_sizes_and_animals(tbl)
    % compute mean and CI of bootstrap means of M and pCV for figures
    unqids = [1,2,6,7,8];
    nAn=5;
    nsz=5;
    mean_CI.mean = zeros(nsz,nAn,4);% '4' = 3 M's + pCV
    mean_CI.CI = zeros(nsz,nAn,4);
    for n = 1:5,
        sz = n;
        tbl_fix_sz = tbl(tbl(:,1)==sz,:);
        tbl_fix_sz_iboot=group_rows_as_HB_samples(tbl_fix_sz);
        [~,~,meanvals_boot,true_Anids,~,~,~]=calcCorrFromTable(tbl_fix_sz_iboot);  
        for iAn = 1:length(unqids)
            meanvals_an = meanvals_boot(true_Anids==unqids(iAn),:);
            out = func_calc_CI(meanvals_an, 0.05);
            mean_CI.mean(n, iAn, :) = out.mu;
            mean_CI.CI(n, iAn, :) = out.CI(1,:);
        end
    end
end


function meanvals_boot = calc_manuscript_means()
    % compute the means of M's exactly as in Fig5
    
    aa=load('tile_ids.mat');
    tile_ids=aa.tile_ids;
    load('hb_10_20_10_fixed_all_but_M.mat')
    tbl_n{1} = tbl;
    load('hb_10_20_5_fixed_all_but_M_2.mat')
    tbl_n{2} = tbl;
    load('hb_10_20_10_fixed_all_but_M_3.mat')
    tbl_n{3} = tbl;
    load('hb_10_20_10_fixed_all_but_M_4.mat')
    tbl_n{4} = tbl;
    load('hb_10_20_10_fixed_all_but_M_5.mat')
    tbl_n{5} = tbl;
    
    tbl_clean = [];
    max_tbl = 0;
    for i = 1:5,
        first_zero = find(tbl_n{i}(:,1)==0,1,'first');
        if ~isempty(first_zero)
            tbl_n{i} = tbl_n{i}(1:first_zero-1,:);
        end
        if i>1,
            tbl_n{i}(:,1) = tbl_n{i}(:,1) + max_tbl;
        end
        max_tbl = max(tbl_n{i}(:,1));
    end
    tbl_clean = cat(1,tbl_n{:});
    tbl_clean = tbl_clean ( tbl_clean(:,1)<=300, : );
    tbl=tbl_clean;
    %
    
    tbl_clean =[];
    unqan = unique( tbl(:,3) );
    for i = 1:length(unqan),
        tbl_an = tbl(tbl(:,3) == unqan(i), :);
        [out,i_excl] = rmoutliers(tbl_an(:,5:8));
        tbl_an(i_excl,:) = [];
        tbl_clean = [tbl_clean; tbl_an];
    end
    tbl = tbl_clean;
    %
    unqids = [1,2,6,7,8];
    nAn=5;
    meanvals_boot = zeros(nAn,4);
    [~,~,mvals,true_Anids,~,~,~]=calcCorrFromTable(tbl);  
    for iAn = 1:length(unqids)
        meanvals_boot(iAn,:) = mean(mvals(true_Anids==unqids(iAn),:));
    end

end


function scatterplots_M_pCV(meanvals_boot, true_Anids)
    plot_every = 1;
    unqa = [1,2,6,7,8];
    colors = {'b','r','m','g','k'};
    figure,
    subplot(1,3,1);
    for i = 1:5,
        ids = find(true_Anids==unqa(i));
        scatter(meanvals_boot(ids(1:plot_every:end),1), meanvals_boot(ids(1:plot_every:end),4), colors{i});
        hold on
    end
    xlabel('M11');ylabel('pCV');
    set(gca,'TickDir','out');

    % add ten linear regression lines: every 5 rows of meanvals_boot come from
    % one bootstrap iteration
    nLines = 10;
    nAn = 5;
    trial_ids_for_lm = randperm( size(meanvals_boot,1) / nAn);
    trial_ids_for_lm = trial_ids_for_lm(1:nLines);
    %
    M_id = 1;
    pCV_id = 4;
    for i = 1:nLines,
        xs = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,M_id);
        ys = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,pCV_id);
        lm = fitlm(xs, ys ) ;
        plot([min(xs);max(xs)], lm.predict([min(xs);max(xs)]),'k');
        hold on
    end
    subplot(1,3,2);
    for i = 1:5,
        ids = find(true_Anids==unqa(i));
        scatter(meanvals_boot(ids(1:plot_every:end),2), meanvals_boot(ids(1:plot_every:end),4), colors{i});
        hold on
    end
    xlabel('M12');ylabel('pCV');
    set(gca,'TickDir','out');
    %
    M_id = 2;
    for i = 1:nLines,
        xs = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,M_id);
        ys = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,pCV_id);
        lm = fitlm(xs, ys ) ;
        plot([min(xs);max(xs)], lm.predict([min(xs);max(xs)]),'k');
        hold on
    end
    subplot(1,3,3);
    for i = 1:5,
        ids = find(true_Anids==unqa(i));
        scatter(meanvals_boot(ids(1:plot_every:end),3), meanvals_boot(ids(1:plot_every:end),4), colors{i});
        hold on
    end
    xlabel('M22');ylabel('pCV');
    set(gca,'TickDir','out');
    set(gcf,'Color',[1 1 1],'Position',[327   718   710   214]);
    %
    M_id = 3;
    for i = 1:nLines,
        xs = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,M_id);
        ys = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,pCV_id);
        lm = fitlm(xs, ys ) ;
        plot([min(xs);max(xs)], lm.predict([min(xs);max(xs)]),'k');
        hold on
    end
end