%% plot the following:
%% OLS, ridge, ALD kernels of an example animal
%% S and F prior of an example animal
%% HB scatter plots of M and prior widths

%% load fitted models (one fit on all data, no bootstrapping)
load('fittingResult.mat', 'resultFitting');

%% panel 1: example animal

animal_id = 2;
kSF = rot90(reshape( resultFitting( animal_id ).khatALD.khatSF , 24, 24),2);
kRidge = rot90(reshape( resultFitting( animal_id ).kRidge, 24, 24),2);
kOLS = rot90(reshape( resultFitting( animal_id ).kLSM, 24, 24),2);

% plot all

figure,
set(gcf,'Position',[311         524        1140         420]);

subplot(1,3,1), imagesc( squeeze(kRidge ) );
formatAxes_hotcold('ridge solution')

subplot(1,3,2), imagesc( squeeze(kOLS ) );
formatAxes_hotcold('OLS solution')

subplot(1,3,3), imagesc( squeeze(kSF ) );
formatAxes_hotcold('ALD solution')

%% panel b: priors

priorS = rot90( reshape( diag(resultFitting( 2 ).khatALD.CpriorS), 24,24), 2);
priorF = rot90( reshape( diag(resultFitting( 2 ).khatALD.CpriorF), 24,24), 2);

figure,
set(gcf,'Position',[104   488   916   420], 'Color',[1 1 1]);
subplot(1,2,1), imagesc( priorS )
formatAxes_hot()

subplot(1,2,2), imagesc( fftshift( priorF ) )
formatAxes_hot_fft()

%% additional panel: inputs (x,y)

yy = randn(100,10);
for i = 1:10,
    yy(:,i) = conv(yy(:,i),ones(10,1)/10,'same')+i;
end
figure, plot(yy)
title('Y (dF/F) schematic');
set(gca,'XTick',[],'YTick',[]);
set(gcf,'Color',[1 1 1]);
set(gcf,'Position',[273   532   180   420]);

xx = randn(10,10);
figure, imagesc(xx>=0.9);
title('X (whl) schematic');
set(gca,'XTick',[],'YTick',[]);
set(gcf,'Color',[1 1 1]);
set(gcf,'Position',[273   532   180   420]);
colormap gray

%func_saveFig('\\172.17.150.7\data\Personal\Andrea intern\final Code Interaction Kernel\figures\',[],150,[],'XY_schematic',1,1,1);
%% panel c: HB scatter plots

load('ccf_M_widthC_workspace_300nBoot.mat');

% scatter, plot 10 regression lines for randomly selected bootstraps

figure,
for iM = 1:3
    xjitter = widths_prior(:)+0.1*randn(size(widths_prior(:)));
    subplot(1,3,iM), scatter( xjitter,reshape(Ms_mean(:,:,iM),[],1),'.')
    title([M_label{iM} ' vs prior width']);
    for i = 1:length(trials_for_regression),
        lm = fitlm(widths_prior(trials_for_regression(i),:), Ms_mean(trials_for_regression(i),:,iM) );
        hold on
        
        minx = min(widths_prior(trials_for_regression(i),:));
        maxx = max(widths_prior(trials_for_regression(i),:));
        h=plot([minx; maxx], lm.predict([minx; maxx]), 'k');
        h.Color = [0.5 0.5 0.5];
    end
    set(gca,'TickDir','out');
    xlabel('prior width, Hz');
    ylabel(M_label{iM});
end
set(gcf,'Color',[1 1 1],'Position',[376   710   660   246]);

% re-label the x axis from "bins of fft" to actual frequencies:
fs = 10;
dt = 0.1; 
fmax = 1/(2*dt); 
kernel_length = 24;
df = fmax/(kernel_length/2); % bin in the frequency domain
labels_bins = get(gca,'XTickLabel');
labels_bins=cellfun(@str2num, labels_bins, 'uni',0);
labels_freq = cellfun(@(x) df*x, labels_bins , 'uni',0);
for i = 1:3
    subplot(1,3,i)
    set(gca,'XTickLabels', labels_freq)%quant(labels_freq,0.01))
end

% stats
disp(['mean correlation of M_{ij} and w : ' num2str(nanmean(ccf_M_widthC))]);
disp(['SE of correlation of M_{ij} and w : ' num2str(nanstd(ccf_M_widthC))]);%/sqrt(size(ccf_M_widthC,1)))]);

disp('same for OLS width:')
disp(['mean correlation of M_{ij} and w : ' num2str(nanmean(ccf_M_widthLS))]);
disp(['SE of correlation of M_{ij} and w : ' num2str(nanstd(ccf_M_widthLS))]);%/sqrt(size(ccf_M_widthLS,1)))]);
%%
function formatAxes_hotcold(title_string)
    load('colormap_fig4.mat','cmap');
    colormap(gca,cmap); 
    caxis([-0.015 0.015])
    title(title_string);
    set(gcf,'Color',[1 1 1]);
    axis image
    set(gca,'XTick',4:5:19, 'YTick',4:5:19);
    set(gca,'XTickLabel',{'0','0.5','1.0','1.5'}, 'YTickLabel',{'0','0.5','1.0','1.5'});
    colorbar
    set(gca,'TickDir','out')
    xlabel('Lag w.r. to body mvt, s');
    ylabel('Lag w.r. to saccade, s');
end

function formatAxes_hot()
    colormap hot
    set(gca,'XTick',4:5:19, 'YTick',4:5:19);
    set(gca,'XTickLabel',{'0','0.5','1.0','1.5'}, 'YTickLabel',{'0','0.5','1.0','1.5'});
    title('time domain prior');
    axis image
    colorbar
    xlabel('Lag w.r. to body mvt, s');
    ylabel('Lag w.r. to saccade, s');    
end

function formatAxes_hot_fft()

    nbins = 24;
    fs = 10;
    dt = 0.1;
    fmax = 1/(2*dt);
    df = fmax/(nbins/2);
    fcoord = -fs/2:df:fs/2;
    fcoord = fcoord(1:end-1);
    labels=mat2cell(fcoord,1,ones(24,1));
    labels=cellfun(@num2str, labels, 'UniformOutput', false);

    xlabels = [5 13 21];
    labels = labels(xlabels);

    set(gca,'XTick',xlabels,'XTickLabel',labels,'YTick',xlabels,'YTickLabel',labels);

    set(gcf,'Color',[1 1 1]);
    title('frequency domain prior');
    axis image
    colorbar

end