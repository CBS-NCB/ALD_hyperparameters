%load('ccf_M_widthC_workspace_300nBoot.mat');
% alternative:
load_clean_hb;

%% compute correlations between all parameter values

[rho_boot,pval_boot,meanvals_boot,true_Anids,meanvals_all,rho_all,pval_all]=calcCorrFromTable(tbl_clean);

%% Figure 5b: pCV(M) scatter and regression lines

unqa = unique(true_Anids);
colors = {'b','r','m','g','k'};
plot_every = 10;% scatter 1/10 of datapoints
figure,
subplot(1,3,1);
for i = 1:5,
    ids = find(true_Anids==unqa(i));
    scatter(meanvals_boot(ids(1:plot_every:end),1), meanvals_boot(ids(1:plot_every:end),4), colors{i});
    hold on
end
xlabel('M_{11}');ylabel('pCV');
set(gca,'TickDir','out');

% add ten linear regression lines: every 5 rows of meanvals_boot come from
% one bootstrap iteration
nLines = 10;
nAn = 5;
trial_ids_for_lm = randperm( size(meanvals_boot,1) / nAn);
trial_ids_for_lm = trial_ids_for_lm(1:nLines);
M_id = 1;
pCV_id = 4;
for i = 1:nLines,
    xs = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,M_id);
    ys = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,pCV_id);
    lm = fitlm(xs, ys ) ;
    h=plot([min(xs);max(xs)], lm.predict([min(xs);max(xs)]),'k');
    h.Color = [0.7 0.7 0.7];
    hold on
end

subplot(1,3,2);
for i = 1:5,
    ids = find(true_Anids==unqa(i));
    scatter(meanvals_boot(ids(1:plot_every:end),2), meanvals_boot(ids(1:plot_every:end),4), colors{i});
    hold on
end
xlabel('M_{12}');ylabel('pCV');
set(gca,'TickDir','out');
M_id = 2;
for i = 1:nLines,
    xs = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,M_id);
    ys = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,pCV_id);
    lm = fitlm(xs, ys ) ;
    h=plot([min(xs);max(xs)], lm.predict([min(xs);max(xs)]),'k');
    h.Color = [0.7 0.7 0.7];
    hold on
end

subplot(1,3,3);
for i = 1:5,
    ids = find(true_Anids==unqa(i));
    scatter(meanvals_boot(ids(1:plot_every:end),3), meanvals_boot(ids(1:plot_every:end),4), colors{i});
    hold on
end
xlabel('M_{22}');ylabel('pCV');
set(gca,'TickDir','out');
set(gcf,'Color',[1 1 1],'Position',[327   718   710   214]);
M_id = 3;
for i = 1:nLines,
    xs = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,M_id);
    ys = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,pCV_id);
    lm = fitlm(xs, ys ) ;
    h=plot([min(xs);max(xs)], lm.predict([min(xs);max(xs)]),'k');
    h.Color = [0.7 0.7 0.7];
    hold on
end


%% stats; 
% alternatively compute these from the data from load_clean_hb which is not restricted to 300 HB iterations

rho_m = mean(rho_boot);
rho_sem = std(rho_boot);% ./ sqrt(size(rho_boot,1)); 

disp(['corr(M11,pCV) = ' num2str(rho_m(4)) ' � ' num2str(rho_sem(4)) ', mean�sem n=300HB']);
disp(['corr(M12,pCV) = ' num2str(rho_m(5)) ' � ' num2str(rho_sem(5)) ', mean�sem n=300HB']);
disp(['corr(M22,pCV) = ' num2str(rho_m(6)) ' � ' num2str(rho_sem(6)) ', mean�sem n=300HB']);

pvalues = sum( rho_boot(:,[4 5 6]) < 0) ./ size(rho_boot,1);
disp('pvalues for corr(M11,pCV), corr(M12,pCV), corr(M22,pCV) are:');
disp(num2str(pvalues))


%% Figure 5a

% establish which mice have high or low M

unqan = unique( tbl_clean(:,3) );
for iAn = 1:length(unqan),
    this_an = unqan(iAn);
    
    M11(iAn) = mean(tbl_clean( tbl_clean(:,3)==this_an, 5 ));
    M12(iAn) = mean(tbl_clean( tbl_clean(:,3)==this_an, 6 ));
    M22(iAn) = mean(tbl_clean( tbl_clean(:,3)==this_an, 7 ));
    
    M11_all{iAn} = tbl_clean( tbl_clean(:,3)==this_an, 5 );
    M12_all{iAn} = tbl_clean( tbl_clean(:,3)==this_an, 6 );
    M22_all{iAn} = tbl_clean( tbl_clean(:,3)==this_an, 7 );
end

M11_group = M11>mean(M11)
M12_group = M12>mean(M12)
M22_group = M22>mean(M22)

% low-M animals: #4,5; high-M animals: #1,2,3

%% plot histograms in the same axes, subsample to 3000 values for every animal

colors_rgb = [0 0 1; 1 0 0; 1 0 1; 0 1 0; 0 0 0];

M_id = 1; % plot for M11, analogous for all others

figure,
for i = 1:5,
    ids = find(true_Anids==unqa(i));
    %histogram( meanvals_boot(ids), 'FaceColor', colors{i});%meanvals_boot(ids(1:plot_every:end))
    
    [N,edges] = histcounts(meanvals_boot(ids,M_id), 'Normalization','pdf');
    
    delta = (edges(2)-edges(1));
    edges = edges(2:end) - delta/2;
    
    %plot(edges, N);
    
    hold on
    
    [s,m,A] = mygaussfit(edges',N');
    
    % add three bins before and after
    edges=[edges(1)-delta*[3 2 1], edges, edges(end)+delta*[1 2 3] ];
    
    plot(edges(1):0.001:edges(end), normpdf(edges(1):0.001:edges(end), m, s));
    
    
end    
hold on, plot( mean(meanvals_boot(:,1))*[1 1], [0 10] , 'k');
    
set(gcf,'Color',[1 1 1]);
set(gca,'TickDir','out');
title('M_{11} distributions for 5 mice, and their mean (black)');
xlabel('M_{11} (bootstrapped) value');
ylabel('number of samples');
set(gcf,'Position',[236   690   401   208]);



% % using dirty data
% nsamples = 3000;
% figure,
% for i = 1:5,
%     sample = randi( length(M11_all{i}), 1, nsamples );
%     histogram(M11_all{i}(sample));
%     hold on
% end


%func_saveFig('\\172.17.150.7\data\Personal\Andrea intern\final Code Interaction Kernel\figures\',[],150,[],'M_distr_schematic',1,1,1);

%% stimulus amplitudes for HB using 'clean_trials' where response to the visual stimulus is isolated

animals_evk = [16032,15352,15312,15098,15100]; %order of increasing M
tiles_evk = [114,127,140,97,139];
tmax_evk = [13,13,14,13,14];
data_root = '..\data';
code_root = '..\code';

% pre-load all data:
stim_ampl = {};
for iAn = 1:length(animals_evk),
    fprintf('.');
    load(fullfile(data_root,['m' num2str( animals_evk(iAn) ) '_model_evk_ac_withTensors05.mat']),'tensor_small_downsampled','clean_trials');
    stim_ampl{iAn} = squeeze(tensor_small_downsampled(tiles_evk(iAn),tmax_evk(iAn), clean_trials ));
end
%%
% bootstrap

nBoot=1000;
for iBoot = 1:nBoot,    
    
    % draw from high-M and low-M group:
    anim_hM = randi(3);
    anim_lM = randi([4 5],1);
    
    N_hM = length(stim_ampl{anim_hM});
    N_lM = length(stim_ampl{anim_lM});
    
    % draw trials
    trials_high_M = randi(N_hM, 1, N_hM);
    trials_low_M = randi(N_lM, 1, N_lM);
    
    % compute sample amplitude and std of stim response
    sample_mean_h(iBoot) = nanmean( stim_ampl{anim_hM}(trials_high_M) );
    sample_mean_l(iBoot) = nanmean( stim_ampl{anim_lM}(trials_low_M) );
    sample_std_h(iBoot) = nanstd( stim_ampl{anim_hM}(trials_high_M) );
    sample_std_l(iBoot) = nanstd( stim_ampl{anim_lM}(trials_low_M) );    
    
    normstd_hM(iBoot) = nanstd( stim_ampl{anim_hM}(trials_high_M)/ (0.0001+nanmean(stim_ampl{anim_hM}(trials_high_M))) );
    normstd_lM(iBoot) = nanstd( stim_ampl{anim_lM}(trials_low_M)/ (0.0001+nanmean(stim_ampl{anim_lM}(trials_low_M))) );
end
normstd_hM = rmoutliers(normstd_hM);
normstd_lM = rmoutliers(normstd_lM);

% pboot: 95th % of low-M compared to 5th-% of high-M
perc_5_highM = prctile(normstd_hM,5);
perc_95_lowM = prctile(normstd_lM,95);
pboot_stim = sum(normstd_lM > perc_5_highM)/length(normstd_lM);
if pboot_stim>0,
    disp(['pboot for stim variability is ' pboot_stim]);
else
    disp(['pboot for stim variability is less than ' num2str(1/nBoot)]);
end

% BOXPLOT for stimulus amplitude
figure, 
ntrials_equalize = randperm(length(normstd_lM));
ntrials_equalize = ntrials_equalize(1:length(normstd_hM));
boxplot([ reshape(normstd_lM( ntrials_equalize ),[],1), normstd_hM( : )]);
set(gcf,'Position',[433   477   223   261]);
set(gca,'TickDir','out');
set(gcf,'Color',[1 1 1]);
box off
ylabel('norm dF/F');
xlabel('low-M high-m groups');
set(gca,'XTickLabel',{'low M','high M'})
