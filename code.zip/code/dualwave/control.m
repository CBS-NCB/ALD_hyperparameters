A64 = load('\\172.17.150.7\data\Personal\Andrea intern\final Code Interaction Kernel\A20064.mat');
moviePath = '\\172.17.150.7\data\MOUSE\IMAGING\GCAMP_DUALW\A20064\A20064_concatenated_correctedDFF.bin';
movieBluePath = '\\172.17.150.7\data\MOUSE\IMAGING\GCAMP_DUALW\A20064\A20064_concatenated_blueDFF.bin';

movieSize = A64.info.concatenatedDFF;
mask = A64.info.concatenatedDFFmask;

movSize = size(mask);
validPixels = find(mask);

Nframes = A64.info.concatenatedDFF(:,2);
fullMovieCorrected = zeros([movSize(1:2) Nframes]);

fID = fopen(moviePath);
for it = 1:Nframes
  mov = fread(fID, length(validPixels), '*single');
  img = zeros(size(mask));
  img(validPixels) = mov;
  fullMovieCorrected(:, :, it) = img;
end
fclose(fID);

fullMovieBlue = zeros([movSize(1:2) Nframes]);
fID = fopen(movieBluePath);
for it = 1:Nframes
  mov = fread(fID, length(validPixels), '*single');
  img = zeros(size(mask));
  img(validPixels) = mov;
  fullMovieBlue(:, :, it) = img;
end
fclose(fID);

%%

% frames of wheel events
wheelPCO = A64.data.wheelEvent.onsetPCO;

% take from 10 frames before to 60 frames after (60 at 30Hz - 2 seconds)
t_window = [10 60];
nEvts = 200;%length(wheelPCO);%100;
wheel_frames = zeros([ movSize(1:2), sum(t_window)+1, nEvts]); 
for ievt = 1:nEvts%length(wheelPCO),
    i_start = max(1, wheelPCO(ievt)-t_window(1));
    i_end = min( size(fullMovieCorrected,3), wheelPCO(ievt)+t_window(2) );
    wheel_frames(:,:,1:(i_end-i_start+1),ievt) = fullMovieCorrected(:,:, i_start:i_end);
end

wheel_frames = wheel_frames - wheel_frames(:,:,1,:);

corrected_w = nanmean(wheel_frames,4);
corrected_w = reshape(corrected_w,[],71);
corrected_w = mean(corrected_w);
figure, plot(corrected_w)

%% little temporary fix to load the video frames only partly 
% fullMovieCorrected = fullMovieCorrected(:,:,1:200000);
% %%
% fullMovieBlue = zeros([movSize(1:2) 200000]);
% fID = fopen(movieBluePath);
% for it = 1:Nframes
%   mov = fread(fID, length(validPixels), '*single');
%   img = zeros(size(mask));
%   img(validPixels) = mov;
%   fullMovieBlue(:, :, it) = img;
% end
% fclose(fID);

wheel_frames_blue = zeros([ movSize(1:2), sum(t_window)+1, nEvts]); 
for ievt = 1:nEvts%length(wheelPCO),
    i_start = max(1, wheelPCO(ievt)-t_window(1));
    i_end = min( size(fullMovieBlue,3), wheelPCO(ievt)+t_window(2) );
    wheel_frames_blue(:,:,1:(i_end-i_start+1),ievt) = fullMovieBlue(:,:, i_start:i_end);
end

wheel_frames_blue = wheel_frames_blue - wheel_frames_blue(:,:,1,:);
blue_w = nanmean(wheel_frames_blue,4);
blue_w = reshape(blue_w,[],71);
blue_w = mean(blue_w);

hold on, plot(blue_w)
%% surface of the brain at approximately the peak
%figure, imagesc( squeeze(blue_w(:,:,30)) );

x_pixels = [10 19];
y_pixels = [25 34];

roi_w = wheel_frames( x_pixels(1):x_pixels(2),y_pixels(1):y_pixels(2),:,:);
roi_w = reshape(roi_w, [], size(roi_w,3), size(roi_w,4));
roi_w = squeeze(mean(roi_w));

figure, plot(mean(roi_w,2));

roi_w_b = wheel_frames_blue( x_pixels(1):x_pixels(2),y_pixels(1):y_pixels(2),:,:);
roi_w_b = reshape(roi_w_b, [], size(roi_w_b,3), size(roi_w_b,4));
roi_w_b = squeeze(mean(roi_w_b));

hold on, plot(mean(roi_w_b,2));


%% same with errorbars

out_corr=func_calc_CI(roi_w',0.05);
out_blue=func_calc_CI(roi_w_b',0.05);

xx = linspace(-0.3,2.0,71);

figure,
shadedErrorBar(xx, out_corr.mu, out_corr.CI(1,:),'r', 0.5);
hold on
shadedErrorBar(xx, out_blue.mu, out_blue.CI(1,:),'b', 0.5);
set(gca,'TickDir','out');
set(gcf,'Color',[1 1 1]);
xlabel('time w.r. to wheel event, s');
ylabel('dF/F');
title('corrected (r) and raw (b) wheel response');
set(gcf,'Position',[680   604   345   374]);

box off;

%% show std of the difference between corrected and uncorrected

dif_std = std(wheel_frames_blue - wheel_frames,[],4);
figure, imagesc(nanmean(dif_std, 3))

caxis([0 0.02]);
axis image
set(gcf,'Color',[1 1 1]);
colorbar
set(gcf,'Position',[696   604   460   383]);
set(gca,'TickDir','out');
title('std of trial-to-trial variation, averaged across timebins');
%%
dif_std = std(mean(wheel_frames_blue,4) - mean(wheel_frames,4),[],3);
figure, imagesc(dif_std)

caxis auto
axis image
set(gcf,'Color',[1 1 1]);
colorbar
set(gcf,'Position',[696   604   460   383]);
set(gca,'TickDir','out');
title({'std of difference between avg blue ','and purple traces; taken over timebins'});

%%
%func_saveFig('\\172.17.150.7\data\Personal\Andrea intern\final Code Interaction Kernel\figures\',[],150,[],'supp_correction',1,1,1);
