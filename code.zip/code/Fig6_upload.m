%%
load('hb_10_20_10_ridgeHP_10.mat', 'tbl')
tbl_10 = tbl;
tbl_10(:,1) = tbl_10(:,1)+900;
load('hb_10_20_10_ridgeHP_9.mat', 'tbl')
tbl_9 = tbl;
tbl_9(:,1) = tbl_9(:,1)+800;
load('hb_10_20_10_ridgeHP_8.mat', 'tbl')
tbl_8 = tbl;
tbl_8(:,1) = tbl_8(:,1)+700;
load('hb_10_20_10_ridgeHP_7.mat', 'tbl')
tbl_7 = tbl;
tbl_7(:,1) = tbl_7(:,1)+600;
load('hb_10_20_10_ridgeHP_6.mat', 'tbl')
tbl_6 = tbl;
tbl_6(:,1) = tbl_6(:,1)+500;
load('hb_10_20_10_ridgeHP_5.mat', 'tbl')
tbl_5 = tbl;
tbl_5(:,1) = tbl_5(:,1)+400;
load('hb_10_20_10_ridgeHP_4.mat', 'tbl')
tbl_4 = tbl;
tbl_4(:,1) = tbl_4(:,1)+300;
load('hb_10_20_10_ridgeHP_3.mat', 'tbl')
tbl_3 = tbl;
tbl_3(:,1) = tbl_3(:,1)+200;
load('hb_10_20_10_ridgeHP_2.mat', 'tbl')
tbl_2 = tbl;
tbl_2(:,1) = tbl_2(:,1)+100;
load('hb_10_20_10_ridgeHP.mat', 'tbl')
tbl_1 = tbl;

tbl = [tbl_1; tbl_2; tbl_3; tbl_4; tbl_5; tbl_6; tbl_7; tbl_8; tbl_9; tbl_10];

%%
%% removing the outliers


tbl_clean =[];

unqan = unique( tbl(:,3) );
for i = 1:length(unqan),
    tbl_an = tbl(tbl(:,3) == unqan(i), :);
    
    [out,i_excl] = rmoutliers(tbl_an(:,5:8));
    tbl_an(i_excl,:) = [];
    
    tbl_clean = [tbl_clean; tbl_an];
end

tbl = tbl_clean;

%% contents of "calcCorrFromTable" adjusted for new table dimensions

rho_boot = [];
pval_boot = [];
meanvals_boot = [];
true_Anids = [];

for iBoot = 1:max( tbl(:,1) )
    tbl_iBoot = tbl( tbl(:,1)==iBoot ,:);
    
    meanvals = [];
    meanvals_all_this_bt = [];
    for iAnimal = 1:max(tbl_iBoot(:,2))% 2nd column in iAn in the bootstrap 
        tbl_iAn = tbl_iBoot( tbl_iBoot(:,2)==iAnimal, :);
        
        % remove outliers within this "animal"; look at columns 5:9 (pCV,invprvar,nsevar,SNR,1/SNR)
        [out,I] = rmoutliers(tbl_iAn(:,5:9));% 8th dim is SNR, 9th is 1/SNR, perhaps doesn't make difference 5:8 or 5:9
        
        iAn_m = mean( out , 1);
        meanvals = [meanvals; iAn_m];
        
        % keep true animal id to color the scatter plot
        true_Anids = [ true_Anids; tbl_iAn(1,3)];
    end
    meanvals_boot = [meanvals_boot; meanvals];
    
    clear this_rho this_pval
    [rho,pval] = corr(meanvals);
    this_rho(1,1:4) = rho(1,2:5);% correlation of pcv with everything: (invpvar,noisevar,SNR,1/SNR)
    this_rho(1,5) = rho(2,3);% correlateion of invpvar and noisevar
    
    rho_boot = [rho_boot; this_rho];
    
    this_pval(1,1:4) = pval(1,2:5);
    this_pval(1,5) = pval(2,3);
    pval_boot = [pval_boot; this_pval];
    
end
pval_snr = sum(rho_boot(:,3)>0)/size(rho_boot,1);
pval_invsnr = sum(rho_boot(:,4)<0)/size(rho_boot,1);

figure, histogram(rho_boot(:,3), 20);% corr(pCV,SNR)
title(['correlation with SNR, pval=' num2str(round(pval_snr, 4))]);
xlabel('corr(SNR,pCV)'); ylabel('nBootstraps');

figure, histogram(rho_boot(:,4), 20);% corr(pCV,1/SNR)
title(['correlation with 1/SNR, pval=' num2str(round(pval_invsnr, 4))]);
xlabel('corr(1/SNR,pCV)'); ylabel('nBootstraps');


figure, histogram(rho_boot(:,5));
title('correlation of invpvar and nsevar');

% stats:
disp(['corr of pCV and 1/SNR: ' num2str( nanmean(rho_boot(:,4)) )]);
disp(['SE of corr of pCV and 1/SNR: ' num2str( nanstd(rho_boot(:,4))) ]);%/sqrt(size(rho_boot,1)) )]);

%% scatter plot with regression lines

unqa = unique(true_Anids);
colors = {'b','r','m','g','k'};
plot_every = 20;
figure,

for i = 1:5,
    ids = find(true_Anids==unqa(i));
    scatter(meanvals_boot(ids(1:plot_every:end),5), meanvals_boot(ids(1:plot_every:end),1), colors{i});% dim_1=pCV,dim_5=1/SNR
    hold on
end
xlabel('1/SNR');ylabel('pCV');
set(gca,'TickDir','out');
set(gcf,'Color',[1 1 1],'Position',[360  370  370  328]);
% add ten linear regression lines: every 5 rows of meanvals_boot come from
% one bootstrap iteration
nLines = 10;
nAn = 5;
trial_ids_for_lm = randperm( size(meanvals_boot,1) / nAn);
trial_ids_for_lm = trial_ids_for_lm(1:nLines);
invSNR_id = 5;
pCV_id = 1;
for i = 1:nLines,
    xs = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,invSNR_id);
    ys = meanvals_boot(1+ (trial_ids_for_lm(i)-1)*nAn : trial_ids_for_lm(i)*nAn,pCV_id);
    lm = fitlm(xs, ys ) ;
    plot([min(xs);max(xs)], lm.predict([min(xs);max(xs)]),'k');
    hold on
end
