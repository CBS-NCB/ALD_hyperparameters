user_path = getenv("USERPROFILE");
desktop_path = user_path + "\Desktop";
data_root = desktop_path + "\data";

%% 1. Fig2a(inset) 

% load a normalization constant - amplide of stim response in its ROI
load(fullfile(data_root, 'm16032_model_evk_ac_noTensors05.mat'),'model_evk');
stim_kern = flipud( model_evk.regr.kRidge_evk );
stim_tile_id  = 114;% stim ROI tile for 16032 
t_peak = 13; % stim response peak (200ms)
t_stim_0 = 10; % stim onset time bin
norm_const = stim_kern(t_peak, stim_tile_id) - stim_kern(t_stim_0, stim_tile_id);

load(fullfile(data_root, 'm16032_seqfit_model_sw_only.mat'),'model_sw');
tile_sw = 124; % tile ROI of interaction
krn = fliplr( flipud( reshape(model_sw.regr.kRidge_sw(tile_sw,:), 24,24) ))  /norm_const;
krnf = filter2( ones(3)*1/9,krn ) ;
krnf = krnf(1:20,1:20);

figure, imagesc(krnf);
load('colormap_fig4.mat','cmap');

title('saccade-wheel mvt interaction kernel')
xlabel('lag since body mvt, s')
ylabel('lag since saccade, s')
set(gca,'TickDir','out')
set(gcf,'Color',[1 1 1])
set(gca,'Color',[0 0 0])

colormap(gca,cmap); 
caxis([-4.5 4.5]);
set(gca,'XTick',4:5:19, 'YTick',4:5:19);
set(gca,'XTickLabel',{'0','0.5','1.0','1.5'}, 'YTickLabel',{'0','0.5','1.0','1.5'});
axis image

colorbar
set(gcf,'Position',[680   663   385   315]);

%% Fig2b: show unfiltered 

figure, imagesc(krn);
load('colormap_fig4.mat','cmap');;
colormap(gca,cmap); 
caxis([-0.03 0.03]);

% % %
title('unfiltered interaction kernel')
xlabel('lag since body mvt, s')
ylabel('lag since saccade, s')
set(gca,'TickDir','out')
set(gcf,'Color',[1 1 1])
set(gca,'Color',[0 0 0])

colormap(gca,cmap); 
caxis([-4.5 4.5]);
set(gca,'XTick',4:5:19, 'YTick',4:5:19);
set(gca,'XTickLabel',{'0','0.5','1.0','1.5'}, 'YTickLabel',{'0','0.5','1.0','1.5'});
axis image

colorbar
set(gcf,'Position',[680   663   385   315]);

%% Fig 2a: diagonals

diag0 = diag(krnf); ncausal0 = length(diag0)-3-1;
diag3 = diag(krnf,3); ncausal3 = length(diag3)-3-1;
diag7 = diag(krnf,7); ncausal7 = length(diag7)-3-1;
diagm3 = diag(krnf,-3); ncausalm3 = length(diagm3)-3-1;
diagm7 = diag(krnf,-7); ncausalm7 = length(diagm7)-3-1;

xs = -0.3:0.1:1.6;

figure, plot(xs,diag0);
hold on, plot(xs(1:end-3),diag3);
hold on, plot(xs(1:end-7),diag7);
hold on, plot(xs(4:end),diagm3);
hold on, plot(xs(8:end),diagm7);

xlabel('time wrt saccade,s');
ylabel('dF/F, norm. to stim response amplitude in its ROI');
title('kernel values for 5 fixed lags');
set(gcf,'Color',[1 1 1],'Position',[680   558   319   420]);


%% Fig2c: fft of the kernel
fs = 10;
dt = 0.1;
fmax = 1/(2*dt);
df = fmax/(length(krn)/2);
fcoord = -fs/2:df:fs/2;
fcoord = fcoord(1:end-1);
labels=mat2cell(fcoord,1,ones(24,1));
labels=cellfun(@num2str, labels, 'UniformOutput', false);

xlabels = [5 13 21];
labels = labels(xlabels);

figure, imagesc( fftshift(abs( fft2(krn)))); colormap hot
set(gca,'XTick',xlabels,'XTickLabel',labels,'YTick',xlabels,'YTickLabel',labels);

set(gcf,'Color',[1 1 1]);
title('abs(fft2) of interaction kernel');
axis image
colorbar

load('colormap_fig2_fft.mat','cmp');
colormap(cmp);
set(gcf,'Position',[217   642   380   317]);
