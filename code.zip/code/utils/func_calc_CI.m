function out = func_calc_CI(data, alpha)
%alpha from 0 to 1;
if nargin<2, alpha=0.05; end
z = norminv(1-alpha/2); % z-Score
N = sum(~isnan(data),1);

if sum(isnan(data(:)))>=1
    
    out.mu  = nanmean(data,1);
    out.sd  = nanstd(data,[],1);
    out.sem = nanstd(data,[],1)./sqrt(N);
    out.CI(1,:) = z.*(out.sem); % the CI (this can be used as input for function shadedErrorBar)
    out.CI(2,:) = z.*(out.sem);
    out.CI(3,:) = out.mu + z.*(out.sem); % the CI around the mean
    out.CI(4,:) = out.mu - z.*(out.sem);
    for i=1:size(data,2)
        ts = tinv([0.025 0.975], N(i)-1); % T-Score
        out.tCI(:,i) = ts*out.sem(i); % the CI around the mean
    end
    
else
    out.mu  = mean(data,1);
    out.sd  = std(data,[],1);
    out.sem = std(data,[],1)./sqrt(N);
    out.CI(1,:) = z*(out.sem);
    out.CI(2,:) = z*(out.sem);
    out.CI(3,:) = out.mu + z*(out.sem);
    out.CI(4,:) = out.mu - z*(out.sem);
    for i=1:size(data,2)
        ts = tinv([0.025 0.975], N(i)-1); % T-Score
        out.tCI(:,i) = ts*out.sem(i); % the CI around the mean
    end
    
end
