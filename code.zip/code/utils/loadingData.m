function [saccX,evokeX,wheelX,yy,yyResidual,peak_w]=loadingData(ssID,do_norm)

if nargin<2,
    do_norm = false;% default: use dF/F, do not normalize to the wheel response amplitude
end
path_dir = "D:\data_d\Data\GCaMP Tensors\Nov18_ac_fit\";
seqFit=join([path_dir 'm' num2str(ssID) '_seqfit.mat'],"");
disp(seqFit)
model_evk=join([path_dir 'm' num2str(ssID) '_model_evk_ac_withTensors05.mat'],"");

disp(['loading data of ' num2str(ssID)]);

aa=load(seqFit, 'pdi');
bb=load(model_evk, 'tensor_small_downsampled');
cc=load(seqFit, 'rsd_ss_ww');

saccX=aa.pdi{1};
evokeX=aa.pdi{2};
wheelX=aa.pdi{3};
yy=bb.tensor_small_downsampled;

yyResidual=cc.rsd_ss_ww;

if do_norm,
    dd = load(seqFit, 'model_s_w');
    t=load('tile_ids.mat','tile_ids');
    tile_ids = t.tile_ids;
    int_tile = tile_ids(tile_ids(:,1)==ssID,2);
    peak_w = max(dd.model_s_w.regr.kRidge_w(int_tile,10:end));
    yy = yy/peak_w;
    yyResidual = yyResidual/peak_w;
end