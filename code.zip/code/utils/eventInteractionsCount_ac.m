function [countmatrix,trial_with_interaction,trial_ids]=eventInteractionsCount_ac(events1,events2,trial_lgt)
% how many trials/interaction cases per bin of kernel

% inputs:
% events1 - logical matrix of event-one onsets, nTime X nTrials
% events2 - logical matrix of event-two onsets, nTime X nTrials
% trial_lgt - consider time bins up until this one, nTrials X 1

% output: 
% countmatrix - matrix of n trials (n datapoints) per kernel element
% trial_with_interaction - ids of trials with an interaction
% trial_ids - trial ids sorted by lags, ids may appear several times

% returns - count matrix, trial index that has the specific interaction 
bins = [-3 20];% timebins of the interaction kernel relative to event onsets, in units of 0.1s
alllags = -bins(2):bins(2);% all possible lags
krnsz = length(bins(1):bins(2));% length of kernel = side of countmatrix 

countmatrix = zeros(krnsz);
trial_with_interaction = false(length(trial_lgt),1);
trial_ids = cell(length(alllags),1);

assert(length(trial_lgt)==size(events1,2));
assert(length(trial_lgt)==size(events2,2));


for iTrial = 1:size(events1,2)
    
    these_events = find(events1(:,iTrial));% these events come first
    relative = find(events2(:,iTrial));% these events come second
    
    for iEvent = 1:length(these_events)
        
        for iLag = 1:length(alllags)
            
            this_bin = these_events(iEvent)+alllags(iLag);% examine this bin relative to the current event
            
            % skip this bin if is outside the trial boundaries
            if this_bin < 1 
                continue
            end
            if this_bin > trial_lgt(iTrial)
                continue
            end
            
            relative_id = relative==this_bin;
            if ~sum(relative==this_bin)% if there is no event in the examined bin
                continue
            end
            
            % otherwise, add to the count matrix: create a vector that will
            % fit along the corresponding diagonal
            mil = krnsz-abs(alllags(iLag));% mil = "maximum interaction length" 
                                           % krnsz - number of krn elements along either axis (=neg_lags + pos_lags + 1)
                                           % abs(iBin) - diagonal is shorter by this many elements
            
            % create a [-lag_anti +lag_causal] window around the two events, and get the length of the intersection
            this_event_window = zeros(trial_lgt(iTrial),1);
            rel_event_window = zeros(trial_lgt(iTrial),1);
            
            this_event_window(max(1,these_events(iEvent)+bins(1)):min(trial_lgt(iTrial),these_events(iEvent)+bins(2)))=1;
            rel_event_window(max(1,relative(relative_id)+bins(1)):min(trial_lgt(iTrial),relative(relative_id)+bins(2)))=1;
            
            interaction_period = this_event_window.*rel_event_window;
            diagcount = zeros(mil,1);
            diagcount(1:sum(interaction_period)) = 1;
            % note that in our data it is never the case that interaction 
            % of pre-saccade and pre-wheel response is cropped by trial 
            % initiation: all saccade and wheel events happen no earlier 
            % than 0.5s from trial start and their pre-event rise is 
            % limited to 0.3s.
            % Because of this, all interactions contribute to the top-left 
            % element of the corresponding diagonal, i.e. diagcount(1)=1
            % always. This can be used as a sanity check. 
            
    
            
               
            countmatrix = countmatrix + diag(diagcount,-alllags(iLag));

            % and make a record that this trial has an interaction
            trial_with_interaction(iTrial) = true;
            
            trial_ids{iLag} = [trial_ids{iLag}; iTrial];
        end
    end
end