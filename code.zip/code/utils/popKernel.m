function lag_lag_stats=popKernel()

% shows Fig2d

% parameters that do not change:
fpsLo = 10; fpsHi = 30;% high and low sampling rates
ol_end = floor(fpsLo*2.5);% timebin end of open loop, 2.5s
krnsz_down = [-3 20];% size of the interaction kernel, timebins [anticausal, causal]
krnlgt = krnsz_down(2)-krnsz_down(1)+1;% kernel length
nTiles = 182;% total n spatial tiles
nmin = 10;% min number of trials
valid_animals_by_count = zeros(krnlgt);% containers for animal counts
n_animals_min = 5;% min number of animals
n_tiles=[];% for 'findTileMin' to find one suppressive tile

% animal ids:
animals_all = [16032,15352,17122,15301,16306,15309,15307,15312,15098,15100,16213,17085,16307,16309];% full animal database
pop_id = [1 2 8 9 10];%[1 2 4 6 8 9 10 12];% all 'excitatory' (Thy1GCaMP) animals with sufficient data (e.g. 15307 is excluded)
stats_id = pop_id;%[1 2 6 8 9 10 12];% an outlier (15301) excluded
%exc_id = [1 2 8 9 10];

% load a colormap
[~,~,cmap] = func_hotcold;

for iAnimal = 1:length(animals_all)
    fprintf('.');
    animal = animals_all(iAnimal);
    
    % load model (for fitted kernels), and input data downsampled to 10Hz (pdi)
    load(['m' num2str(animal) '_seqfit_eyewhl.mat'],'model_sw','pdi');
    
    % load a pre-computed mask on tiles based on response intensity
    load(['m' num2str(animal) '_mask.mat'],'masked_plus_one_flag');
    
    % eye-wheel interactions are fitted in several bootstraps; average
    % across them and use the resulting kernel
    krn = model_sw.regr.kRidge_sw;
    krn = fliplr(krn);% reverse the time 
    
    % filter mean kernel
    krnf = krnfilt({krn},krnlgt,krnlgt); krnf = krnf{1}; 
    
    % calculate data count, to mask values with fewer than n=10 datapoints
    nTrials = size(pdi{1},2);
    count=eventInteractionsCount_ac(pdi{1},pdi{3},ol_end*ones(nTrials,1));
    
    % reshape krn to nTiles X lags X lags (final form)
    krn_this = reshape(krn,nTiles,krnlgt,krnlgt); clear krn; 
    for iTile = 1:nTiles, krn(:,:,iTile) = squeeze(krn_this(iTile,:,:)); end
    
    % average filtered and average unfiltered, both within tile_vis
    [krnmin_id,tile_vis]=findTileMin(krnf, double(count>nmin), ~masked_plus_one_flag);
    [xmin(iAnimal),ymin(iAnimal)] = ind2sub([krnlgt krnlgt],krnmin_id);% keep as index to show the max suppression element on a population average kernel
    krnf_vis = nanmean(krnf(:,:,tile_vis),3); 

    % accumulate normalized filtered and unfiltered kernels
    maxsuppf=min(krnf_vis(count>=nmin)); 
    krnf_vis_norm_all(:,:,iAnimal) = krnf_vis/abs(maxsuppf); 
    krnf_vis_norm_all(krnf_vis_norm_all==0)=nan;
    
    % compute number of animals per element of kernel
    if ismember(iAnimal,pop_id),
        valid_animals_by_count = valid_animals_by_count+(count>=nmin);
    end
    
end
close(gcf)

% calculate and show average of normalized kernels across mice
krnf_vis_norm = squeeze(nanmean(krnf_vis_norm_all(:,:,pop_id),3));
nanmask = double(valid_animals_by_count>=n_animals_min); nanmask(nanmask==0)=nan;% blacken all the elements outside the significant parts
h=showSummary(krnf_vis_norm.*nanmask,[-1 1],valid_animals_by_count,'pop norm avg, filtered',n_animals_min,1:17);
lag_lag_stats=scatterMinima(h,xmin,ymin,stats_id);
popavg_formatting(h,cmap);

% generate a figure where the "nan" elements are set to black not by making
% them transparent, but by creating a value in the colormap
cmap(1,:) = [ 0 0 0 ];
nanmask = double(valid_animals_by_count>=n_animals_min); 
masked_kernel=krnf_vis_norm.*nanmask;
masked_kernel(isnan(masked_kernel)) = -1;
masked_kernel( masked_kernel == 0) = -1;
h=showSummary(masked_kernel,[-1 1],valid_animals_by_count,'pop norm avg, filtered',n_animals_min,1:17);
lag_lag_stats=scatterMinima(h,xmin,ymin,stats_id);
popavg_formatting(h,cmap);

function h=showSummary(krnf_vis_norm,clims,valid_animals_by_count,which_figure,n_animals_min,limxy)

if nargin<6, limxy = 1:20; end
alphamask = ones(size(krnf_vis_norm));
% alphamask = ones(size(krnf_vis_norm));
% alphamask(valid_animals_by_count<n_animals_min)=0.2;
% alphamask((krnf_vis_norm==0)|isnan(krnf_vis_norm))=0;

figure,
imagesc(krnf_vis_norm(limxy,limxy),...
    'AlphaData',alphamask(limxy,limxy));
applyKernelFormatting; colormap redblue; caxis(clims);
title(which_figure);
xlabel('time since whl'); ylabel('time since sac')
axis square
set(gcf,'Position',[680 287 465 374])
h=gcf;

set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 10 20]);
set(gcf,'Color',[1 1 1])
set(gcf,'Position',[150   460   368   331]);


function popavg_formatting(h,cmap)
if nargin<2, cmap = redblue; end
    
set(h,'Position',[108   217   364   311]);
title('saccade-wheel mvt interaction kernel')
xlabel('lag since body mvt, s')
ylabel('lag since saccade, s')
set(gca,'TickDir','out')
set(gcf,'Color',[1 1 1])
set(gca,'Color',[0 0 0])

colormap(gca,cmap); caxis([-0.8 0.8]);


function lag_lag_stats = calcLagLagStats(xmin,ymin)

dt = 0.1; % bin width
t0 = 4; % timebin of event onset

fprintf('time bin width %1.1f s ',dt)
xmin_time = dt*(xmin-t0);
ymin_time = dt*(ymin-t0);

lag_lag_stats.xmean_bin = nanmean(xmin);
lag_lag_stats.ymean_bin = nanmean(ymin);
lag_lag_stats.xsem_bin = std(xmin)./sqrt(length(xmin));
lag_lag_stats.ysem_bin = std(ymin)./sqrt(length(ymin));

lag_lag_stats.xmean_time = nanmean(xmin_time);
lag_lag_stats.ymean_time = nanmean(ymin_time);
lag_lag_stats.xsem_time = std(xmin_time)./sqrt(length(xmin_time));
lag_lag_stats.ysem_time = std(ymin_time)./sqrt(length(ymin_time));

fprintf('\n')
disp('population peak:')
disp('bin coordinates, body mvt:')
disp([num2str(lag_lag_stats.ymean_bin) ' � ' num2str(lag_lag_stats.ysem_bin)])
disp('bin coordinates, saccade:')
disp([num2str(lag_lag_stats.xmean_bin) ' � ' num2str(lag_lag_stats.xsem_bin)])

disp('population peak:')
disp('lag from body mvt, in s:')
disp([num2str(lag_lag_stats.ymean_time) ' � ' num2str(lag_lag_stats.ysem_time)])
disp('lag from saccade, in s:')
disp([num2str(lag_lag_stats.xmean_time) ' � ' num2str(lag_lag_stats.xsem_time)])


function lag_lag_stats=scatterMinima(h,xmin,ymin,exc_id)

% scatters lag-lag of most suppressive elements and of the mean, takes care
% of the outlier
xmin = xmin(exc_id);
ymin = ymin(exc_id);
hold on, hh=scatter(ymin+0.5*rand(1,length(xmin)),...
    xmin+0.5*rand(1,length(xmin)),'.r'); set(hh,'Sizedata',200)
% get the location of population average and error bars:
lag_lag_stats = calcLagLagStats(xmin,ymin);
hold on, h=errorbarxy(lag_lag_stats.ymean_bin,lag_lag_stats.xmean_bin,...
    lag_lag_stats.ysem_bin,lag_lag_stats.xsem_bin,{'or','r','r'}); 
set(h.hMain,'MarkerSize',10,'LineWidth',2);



function applyKernelFormatting(h)

% apply same labels to sac-stim panels

if nargin<1, h=gca; end

set(h,'Color',[0 0 0])
colorbar

set(h,'YTick',[4 9 14 19])
set(h,'YTickLabel',[0 0.5 1.0 1.5])
set(h,'XTick',[4 9 14 19])
set(h,'XTickLabel',[0 0.5 1.0 1.5])

set(gcf,'Position',[149 186 1167 384])

set(gca,'TickDir','out')
box on