function areacontours=getAverageAreaContours()

disp('loading population average contours')
DB = load('exc_avg_retino.mat'); %'C:\svn2\GCaMP Kernels\exc_avg_retino.mat'

areas_labeled  = zeros(251,251);
areas_labeled(DB.usedRoi.x,DB.usedRoi.y) = bwlabel(DB.visareas,4);

nAreas = length(unique(areas_labeled(:)))-1;
areacontours = cell(nAreas,1);
for i=1:nAreas
    imbin = zeros(size(areas_labeled));
    imbin = (imbin+(areas_labeled==i))>0;
    tc = contour(imbin,[0.1 0.1]);
    x1 = tc(1,2:end);
    x2 = tc(2,2:end);
    areacontours{i,1}=x1;
    areacontours{i,2}=x2;
end