function [imh,wholemap]=showSurface(graphmodel,map,h,discarded_var,align_only)
% plot vectorized map on a grid given by graphmodel

% graphmodel structure with fields:
% xsmall, ysmall - sizes of the downsampled brain surface frame
% selecttiles - tile centers in the coordinates of the original full-size image
% align_only - only compute "wholemap" but don't show the actual surface

if nargin<2
    map = randn(182,1);
end

wholemap = nan(graphmodel.xsmall,graphmodel.ysmall);

assert(length(map)==182); % default case, nTiles=182

% graphically expand the pixels x5
for i = 1:length(map)
    [xthis,ythis] = ind2sub([graphmodel.xsmall graphmodel.ysmall],graphmodel.selecttiles(i));
    xthismin = max(1,xthis-2);ythismin = max(1,ythis-2);
    xthismax = min(graphmodel.xsmall,xthis+2); ythismax = min(graphmodel.ysmall,ythis+2);
    wholemap(xthismin:xthismax,ythismin:ythismax)=map(i);
end


% show the map
if ~align_only
    
    if nargin<3
        figure,
    elseif isempty(h)
        figure,
    else
        axis(h);
    end
    
    mask = (~isnan(wholemap));
    imh=imagesc(wholemap,'AlphaData',mask);
        
    fname = fullfile('..',['data\m' num2str(model.animal) '_contours.mat']);
    load(fname,'areacontours');
    
    set(gca,'Color',[0 0 0])
    for i = 1:length(areacontours)
        hold on, h=plot(areacontours{i,1},areacontours{i,2},'m');
        set(h,'LineWidth',2)
    end
    
    axis image; colorbar
    
else
    imh=[];
end
