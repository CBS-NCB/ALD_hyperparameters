function [aligned_frames_all,aligned_frames_filt_all]=predictAndAlignAll(animals_all,count_mask,lags,timebins,which_interaction)
% predict and spatially align the predicted tensors

if nargin<5, which_interaction = 'saccade-stimulus'; end

% create a container array for the aligned data; load the alignment parameters
container = nan(251,251);
load('com.mat','cdat')
load('final.mat','fdat','pdat')


for iLag = 1:length(lags)
    disp([' ----- predicting lag ' num2str(iLag) ' of ' num2str(length(lags)) ' ----- ']);
    for iAnimal = 1:length(animals_all)
        
        disp(['animal ' num2str(iAnimal)])
        % load a model (any of the current animal) to use its graphics fields
        load(['m' num2str(animals_all{iAnimal}) '_model_evk_ac_withTensors05.mat'], 'model_evk');
        model=model_evk;
        
        % PREDICT
        
        % use mask of where the kernel elements are nan/have too few
        % data points (count_mask); if no mask - provide only two arguments
        switch which_interaction
            case 'wheel-stimulus'
                disp('generate prediction of wheel-stimulus interaction')
                [rhat_all{iLag}(:,:,iAnimal),rhatf_all{iLag}(:,:,iAnimal)] = ...
                    predictWheelStimInteraction(animals_all{iAnimal},lags(iLag),squeeze(count_mask(:,:,iAnimal)));
            case 'saccade-stimulus'
                disp('generate prediction of saccade-stimulus interaction')
                [rhat_all{iLag}(:,:,iAnimal),rhatf_all{iLag}(:,:,iAnimal)] = ...
                    predictSacStimInteraction(animals_all{iAnimal},lags(iLag),squeeze(count_mask(:,:,iAnimal)));
            case 'saccade-wheel'
                disp('generate prediction of saccade-wheel interaction')
                [rhat_all{iLag}(:,:,iAnimal),rhatf_all{iLag}(:,:,iAnimal)] = ...
                    predictSacWheelInteraction(animals_all{iAnimal},lags(iLag),squeeze(count_mask(:,:,iAnimal)));

        end
        
        % ALIGN
        
        % unfiltered
        this=alignPredictedTensors(container,animals_all{iAnimal},squeeze(rhat_all{iLag}(:,timebins,iAnimal)),model,cdat,fdat);
        this(this==0) = nan;
        aligned_frames_all{iLag}(:,:,:,iAnimal) = this;
        
        % filtered
        this=alignPredictedTensors(container,animals_all{iAnimal},squeeze(rhatf_all{iLag}(:,timebins,iAnimal)),model,cdat,fdat);
        this(this==0) = nan;
        aligned_frames_filt_all{iLag}(:,:,:,iAnimal) = this;
        
        
    end
end