function [krnmin_id,tilemin_id]=findTileMin(this_krn,count_mask,tile_mask)

[krnlgt,krnlgt,nTiles] = size(this_krn); 

tile_mask_3d(1,1,:) = tile_mask;

% mask kernel elements by data point counts
mask3d = repmat(count_mask,1,1,nTiles);
this_krn = this_krn.*mask3d;

% mask tiles by blood vessels/chamber
mask3d = repmat(tile_mask_3d,krnlgt,krnlgt,1);
this_krn = this_krn.*mask3d;

this_krn = reshape(this_krn,krnlgt*krnlgt,nTiles);
kmin = min(this_krn(:));
[krnmin_id,tilemin_id]=find(this_krn==kmin);
