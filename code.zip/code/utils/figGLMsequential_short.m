function figGLMsequential_short()

% prediction of sequentially fitted, example mouse, uses precomputed
% tensors

animal = 15100;
tile_ROI = 151;
krnsz = [-3 20];

load('m15100_seqfit.mat','rhat_e_tensor','rhat_w_tensor','pdi');
load('m15100_model_evk_ac_withTensors05.mat', 'rhat_evk_tensor','tensor_small_downsampled');
load('m15100_rhat_sw.mat','rhat_sw');

tri_int = sum(pdi{1}>0)&sum(pdi{3}>0);

pred_evk = squeeze(nanmean(rhat_evk_tensor(tile_ROI,1:25,tri_int),3));
evk_peak = max(pred_evk);
pred_evk = pred_evk /evk_peak;
pred_cd_iso = squeeze(nanmean(rhat_e_tensor(tile_ROI,1:25,tri_int)+rhat_w_tensor(tile_ROI,1:25,tri_int),3)) /evk_peak;
pred_cd_inter = squeeze(nanmean(rhat_sw(tile_ROI,1:25,tri_int),3)) /evk_peak;

data_out = func_calc_CI(squeeze(tensor_small_downsampled(tile_ROI,1:25,tri_int))' /evk_peak,0.05) ;

figure,
x = -1:0.1:1.4;
hold on, shadedErrorBar(x,data_out.mu,data_out.CI(1,:),'k',0.5);
hold on, plot(x,pred_evk,'g')
hold on, plot(x,pred_evk+pred_cd_iso,'r')
%hold on, plot(x,pred_evk+pred_cd_iso+pred_cd_inter,'b')
hold on, plot(x,data_out.mu - (pred_evk+pred_cd_iso), 'm');

set(gcf,'Color',[1 1 1]);
xlabel('time to stim onset,s')
ylabel('dF/F normalized to stim response peak');
