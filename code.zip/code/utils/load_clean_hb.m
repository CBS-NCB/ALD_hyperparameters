% alternative to loading the HB values of M directly (Figures 3,4,5)

load('hb_10_20_10_fixed_all_but_M.mat')
tbl_n{1} = tbl;

load('hb_10_20_5_fixed_all_but_M_2.mat')
tbl_n{2} = tbl;

load('hb_10_20_10_fixed_all_but_M_3.mat')
tbl_n{3} = tbl;

load('hb_10_20_10_fixed_all_but_M_4.mat')
tbl_n{4} = tbl;

load('hb_10_20_10_fixed_all_but_M_5.mat')
tbl_n{5} = tbl;

tbl_clean = [];
max_tbl = 0;
for i = 1:5,
    first_zero = find(tbl_n{i}(:,1)==0,1,'first');
    if ~isempty(first_zero)
        tbl_n{i} = tbl_n{i}(1:first_zero-1,:);
    end
    if i>1,
        tbl_n{i}(:,1) = tbl_n{i}(:,1) + max_tbl;
    end
    max_tbl = max(tbl_n{i}(:,1));
end

tbl_clean = cat(1,tbl_n{:});
tbl_clean = tbl_clean ( tbl_clean(:,1)<=300, : );
tbl=tbl_clean;

%% 

tbl_clean =[];

unqan = unique( tbl(:,3) );
for i = 1:length(unqan),
    tbl_an = tbl(tbl(:,3) == unqan(i), :);
    
    [out,i_excl] = rmoutliers(tbl_an(:,5:8));
    tbl_an(i_excl,:) = [];
    
    tbl_clean = [tbl_clean; tbl_an];
end

tbl = tbl_clean;
