function aligned_frames=alignPredictedTensors(container,animal,rhat,model,cdat,fdat)

% spatially align dF/F tensors

tmpO = 126;% figure center
[nTiles, nTime] = size(rhat);
[nRow,nCol] = size(container);
aligned_frames = nan(nRow,nCol,nTime);

% get animal id
animals=[15098;15100;15301;15307;15309;15312;15352;16032;16122;16199;16213;16306;16307;16309;17085;17122];% database order of animals; also in fdat/cdat
animal_id = find(animals==animal);% animal id in fdat/cdat files

fidx = find(strcmp({cdat.filename},'A15309'));% mouse to which everything is aligned

% alignment coordinates, compute once >>>
clear BW V1_Cnt foo OO dum
BW = bwlabel(fdat(animal_id).visap_us,4);

Angle = -(cdat(animal_id).dir - cdat(fidx).dir) *180/pi;
BW = imrotate(BW,Angle,'crop');

dum = nan(size(BW,1),size(BW,2),max(BW(:)));
for iA = 1:max(BW(:))
    dum(:,:,iA) = bwareaopen(BW==iA,5,4)*iA;
end
BW = sum(dum,3);

foo = regionprops(BW == cdat(animal_id).V1idx,'Centroid');
V1_Cnt = round(foo.Centroid);
if animal_id==1, V1_Cnt(2) = V1_Cnt(2)+5;end
% <<<

% display an activation map at every time bin, rotate, save as a frame
for iTime = 1:nTime
    fprintf('.')
    
    align_only = true; 
    [~,wholemap]=showSurface(model, squeeze(rhat(:,iTime)),[],[],align_only);    
        
    if ~isempty(wholemap)
        BW1 = imresize(wholemap,size(BW),'nearest');
        BW1 = imrotate(BW1,Angle,'crop');
    else
        BW1 = nan(size(BW));
    end
    
    OO = [tmpO - V1_Cnt(1), tmpO - V1_Cnt(2)];
    aligned_frames( OO(2): OO(2)+size(BW,1)-1 , OO(1): OO(1)+size(BW,2)-1 , iTime) = BW1;
end
