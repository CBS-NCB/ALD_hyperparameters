function [rho_boot,pval_boot,meanvals_boot,true_Anids,meanvals_all,rho_all,pval_all]=calcCorrFromTable(tbl)

rho_boot = [];
pval_boot = [];
meanvals_boot = [];
true_Anids = [];
meanvals_all = [];
rho_all = [];
pval_all = [];
for iBoot = 1:max( tbl(:,1) )
    tbl_iBoot = tbl( tbl(:,1)==iBoot ,:);
    
    meanvals = [];
    meanvals_all_this_bt = [];
    for iAnimal = 1:max(tbl_iBoot(:,2))% 2nd column in iAn in the bootstrap 
        tbl_iAn = tbl_iBoot( tbl_iBoot(:,2)==iAnimal, :);
        
        % remove outliers within this "animal"
        [out,I] = rmoutliers(tbl_iAn(:,5:8));% 9th dimension is q, unnecessary
        
        iAn_m = mean( out , 1);
        meanvals = [meanvals; iAn_m];
        % (new/control) output all other parameter values as well
        tbl_other = tbl_iAn;
        tbl_other(I,:) = [];
        meanvals_all_this_bt = [meanvals_all_this_bt; mean(tbl_other, 1)];
        
        % keep true animal id to color the scatter plot
        true_Anids = [ true_Anids; tbl_iAn(1,3)];
    end
    meanvals_boot = [meanvals_boot; meanvals];
    meanvals_all = [meanvals_all; meanvals_all_this_bt];
    
    clear this_rho this_pval
    [rho,pval] = corr(meanvals);
    this_rho(1,1) = rho(1,2);% M11 x M12
    this_rho(1,2) = rho(1,3);% M11 x M22
    this_rho(1,3) = rho(2,3);% M12 x M22
    this_rho(1,4:6) = rho(1:3,4); % M11,12,22 x pCV
    %this_rho(1,7:10) = rho(1:4,5); % M11,12,22,pCV x dQ
    rho_boot = [rho_boot; this_rho];
    
    this_pval(1,1) = pval(1,2);% M11 x M12
    this_pval(1,2) = pval(1,3);% M11 x M22
    this_pval(1,3) = pval(2,3);% M12 x M22
    this_pval(1,4:6) = pval(1:3,4); % M11,12,22 x pCV
    %this_pval(1,7:10) = pval(1:4,5); % M11,12,22,pCV x dQ
    pval_boot = [pval_boot; this_pval];
    
    % (new/control) correlations and pvalues of all other pairs
    clear this_rho this_pval
    [rho,pval] = corr( meanvals_all_this_bt );
    % p_id is 8, all other ids are new_ids = [10,11,12,13,14,15,16,17];
%     this_rho = [rho(8,5:7) rho(8,10:17)];
%     this_pval = [pval(8,5:7) pval(8,10:17)];
%     rho_all = [rho_all; this_rho];
%     pval_all = [pval_all; this_pval];
end