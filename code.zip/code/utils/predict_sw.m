function [rsd_x_evk,rhat_tensor]=predict_sw(pdi,ndim,kRidge,rsd_ss_ww,krnsz)

%NOTE, this function is only used in the simulation of the nonlinear part

% predict saccade-wheel interactions using already fitted kernels and an
% arbitrary input

tr_lg = 35;% hard-coded, duration of the trial; needs to fit the simulated interactions
nTiles = ndim.nTiles;
nTrials = ndim.nTrials;

if nargin<5, rsd_ss_ww = zeros(nTiles,tr_lg,nTrials); disp('NOTE! input residual tensor is a placeholder. Do not use output residuals'); end
if nargin<6, krnsz = [-3 20]; end % hard coded, size of 2d kernel in each dimension


snip_full = [ones(nTrials,1) tr_lg*ones(nTrials,1)]; 
trial_lgt_down = tr_lg*ones(nTrials,1);

% in case fewer trials are actually going to be used:
for i = 1:length(pdi)
    pdi{i} = pdi{i}(:,1:nTrials);
end

dta=prepPredictors_ac(pdi,{krnsz},snip_full,(1:nTrials)',trial_lgt_down,[],false,{[1 2]},false);

if ndims(kRidge)==3
    kRidge_mean = (squeeze(nanmean(kRidge,2)))';
else
    kRidge_mean = kRidge';
end
rhat = dta*kRidge_mean;

rhat_tensor = nan(nTiles,tr_lg,nTrials);

% write into tensor
for iTile = 1:nTiles
    disp(iTile)
    index = 1;
    for iTrial = 1:nTrials
        rhat_tensor(iTile,:,iTrial)=rhat(index:(index+tr_lg-1),iTile);
        index = index + tr_lg;
    end
end
assert(index-1 == size(dta,1));

rsd_x_evk = rsd_ss_ww(:,1:tr_lg,:)-rhat_tensor;
