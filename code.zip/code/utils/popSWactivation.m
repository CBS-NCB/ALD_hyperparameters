function popSWactivation()

% shows a population summary of eye-wheel interaction responses on the
% brain surface 
% 
% 
% 1) simulates responses for a fixed set of wheel-eye lags and time bins,
% 2) shows an example frame (corresponding to pre-selected
% suppression element of the population kernel), 
% 3) shows a grid of frames that correspond to selected elements of the kernel

animals_all = {16032,15352,17122,15301,16306,15309,15307,15312,15098,15100,16213,17085,16307,16309};% full database of animals
filtersize = 20; % spatial filter for surface maps
do_show_grid = false; % predict and show maps of interactions at a range of lags; off by default


% 1. 
count_all=getAllCounts(animals_all);
count_all(count_all==0) = nan;

% b. set lags and timebins for the simulation. 

% (The following conventions facilitate the simulation of responses in predictAndAlignAll)
%
% Lags are in units of 0.1s, and are the time difference between wheel and 
% stimulus onsets, i.e. lag=(t_whl-t_eye)./0.1s. 
%
% Timebins (also in units of 0.1s) are timebin # of the response to be simulated.
% I.e. "timebins=1" corresponds to simulating the only the first frame of a trial. 
%
% Event onset is hard-coded at t0=10 inside
% predictAndAlignAll.m > predictSacWheelInteraction.m 

t0=10;
lags = [-5 0 5]; % relative lag between saccade and wheel
timebins{2} = t0+[0 2 5 7];% (lag=0) % simulate these four timebins (frames) in the trial with saccade-wheel lag=0
timebins{1} = [ t0-lags(1)+[0 2]];%lag=-5, saccade before wheel, timebins relative to the later event
timebins{3} = [ t0+[0 2]];%lag=5, wheel before saccade, timebins relative to the later event

% c. make sure the animals used are the "best five"
exc_id = [1 2 8 9 10];
ok_animals = exc_id; clims = [-3.5 3.5];


% d. predict for the three lags
%[aligned_frames_all(1),aligned_frames_filt_all(1)]=predictAndAlignAll(animals_all(ok_animals),count_all(:,:,ok_animals),lags,timebins{1},'saccade-wheel');
[aligned_frames_all(1),aligned_frames_filt_all(1)]=predictAndAlignAll(animals_all(ok_animals),count_all(:,:,ok_animals),lags(1),timebins{1},'saccade-wheel');
[aligned_frames_all(2),aligned_frames_filt_all(2)]=predictAndAlignAll(animals_all(ok_animals),count_all(:,:,ok_animals),lags(2),timebins{2},'saccade-wheel');
[aligned_frames_all(3),aligned_frames_filt_all(3)]=predictAndAlignAll(animals_all(ok_animals),count_all(:,:,ok_animals),lags(3),timebins{3},'saccade-wheel');
% ... or load! 
%load('D:\Data\GCaMP Tensors\Nov18_ac_fit\saccade_wheel_simulation.mat','aligned_frames_filt_all');


% 2.

% get area contours
areacontours=getAverageAreaContours;
close(gcf)

% show an example frame: lag=0.5s and t=0.2s since saccade
iFrame = find(timebins{lags==5}==t0+2);%
ilag = find(lags==5);

showExampleFrame_sacWhl(animals_all(ok_animals),aligned_frames_filt_all,areacontours,iFrame,ilag,timebins{lags==5},lags);

load('cmap_sw_pred.mat','cmap_best_frame');
colormap(gca,cmap_best_frame);
caxis(clims);

function showGrid(zscore_means,lags_vector,timebins_vector,subplots_vector,areacontours,nanmask)
load('cmap_sw_pred.mat','cmap_sw_pred');

t0=10;
figure,

for i = 1:length(subplots_vector)
    h=subplot(4,2,subplots_vector(i));
    
    alphadata = ones(size(zscore_means,1),size(zscore_means,2));
    alphadata(nanmask) = 0.2;
    imagesc(squeeze(zscore_means(:,:,i)),'AlphaData',alphadata);
    pos = get(gca,'Position');
    a = pos(1);b = pos(2);c = pos(3);d = pos(4);
    
    set(gca,'Visible','off');
    set(gcf,'Position',[37    50   344   586]);
    
    if mod(subplots_vector(i),4)==1,
        %[a b c d]
        a = 0.18;
    elseif mod(subplots_vector(i),4)==3,
        a = 0.325;
    elseif mod(subplots_vector(i),4)==2,
        a = 0.47;
    elseif mod(subplots_vector(i),4)==0,
        a=  0.62;
    end
    
    if ismember(subplots_vector(i),[3 4])
        b = 0.603;
    elseif ismember(subplots_vector(i),[5 6])
        b = 0.435;
    elseif ismember(subplots_vector(i),[7 8])
        b = 0.27;
    end
    
    axis square
    set(gca,'XLim',[50 190],'YLim',[40 180]);
    
    for j = 1:length(areacontours)
        hold on
        plot(areacontours{j,1},areacontours{j,2},'k')
    end
    
    set(gca,'Position',[a b c d])
    caxis([-3 3]); colormap(gca,cmap_sw_pred);
    
    this_lag = lags_vector(i);
    this_frame = timebins_vector(i);
    
    lag_label = [num2str(0.1*(this_frame-t0)) ',' num2str(0.1*(this_frame-t0+this_lag))];
    text(155,45, ['(' num2str(lag_label) ')' ]);
end


function count_all=getAllCounts(animals_all)

fpsLo = 10; 
ol_end = floor(fpsLo*2.5);

animals_all = cell2mat(animals_all);

for iAnimal = 1:length(animals_all),
    animal = animals_all(iAnimal);
    % load inputs
    load(['m' num2str(animal) '_seqfit_eyewhl.mat'],'pdi');
    nTrials = size(pdi{1},2);
    count=eventInteractionsCount_ac(pdi{1},pdi{3},ol_end*ones(nTrials,1));
    count_all(:,:,iAnimal) = count;
end