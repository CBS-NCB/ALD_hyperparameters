function [rhat,rhatf] = predictSacWheelInteraction(animal,lag,masked_kern)

% simulates a response due to saccade-body movement interaction: with and
% without filtering the kernel of each tile (in lag-lag space)

% inputs:
% animal - animal_id
% lag - positive for stimulus before saccade, in units of 200ms

% load the fitted saccade-stimulus interaction kernel
load(['m' num2str(animal) '_seqfit.mat'],'model_sw','pdi');
model = model_sw; clear model_sw;

kRidge = model.regr.kRidge_sw_boot;
nTrials_sim = 1;
nTiles = size(kRidge,1);
krnlgt = sqrt(size(kRidge,3));
krnsz = [-3 20];
trial_lgt = 35;% arbitrary: interactions need to fit into a trial (hence t0 + length of kernel diagonal)


disp('NOTE that kernel size is hard-coded at [-3 20] bins');
%if ~isfield(model,'selecttiles'), model.selecttiles = 1:nTiles; end
if nargin<3, masked_kern = ones(krnlgt); end% no mask
mask = fliplr(flipud(~isnan(masked_kern))); mask = repmat(mask(:),1,nTiles); mask = mask'; mask3d(:,1,:) = mask;

% create inputs: an event in each channel 
t0=10;% time bin of event in input 2; arbitrary - interactions just need to fit into a trial
input1 = zeros(trial_lgt,1); input1(t0,1)=1;% saccade input
input2 = zeros(trial_lgt,1); input2(t0-lag,1)=1;% wheel input
disp(['event 1 (saccade) occurs at bin ' num2str(t0) ', event 2 (body mvt) occurs at bin ' num2str(t0-lag)]) 

% create the model with necessary inputs
model_sim = model;
model_sim.data.inputs{1} = input1;
model_sim.data.inputs{2} = input2;
if numel(model_sim.data.inputs)==3, model_sim.data.inputs(3) = [];end
model_sim.data.trial_lgt = trial_lgt;

% generate response with an UNfiltered kernel
rsd = zeros(nTiles,model_sim.data.trial_lgt,1);% just a placeholder for predict_x_evk.m to run 
ndim.nTiles = nTiles;
ndim.nTrials = 1;
mask_this = repmat(mask3d,[1 size(kRidge,2) 1]);
[~,rhat]=predict_sw(model_sim.data.inputs,ndim,kRidge.*mask_this,rsd,krnsz); clear mask_this

% filter the kernel (average over bootstraps then filter, filtering then
% averaging would not be that much different)
krn = squeeze(nanmean(kRidge,2));
krnf = krnfilt({krn},krnlgt,krnlgt); krnf = krnf{1};
krnf = reshape(krnf,krnlgt*krnlgt,nTiles); krnf = krnf'; kern_sw(:,1,:) = krnf;
mask_this = repmat(mask3d,[1 size(kern_sw,2) 1]);
[~,rhatf]=predict_sw(model_sim.data.inputs,ndim,kern_sw.*mask_this,rsd,krnsz); clear mask_this
