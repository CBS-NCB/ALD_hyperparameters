function [c_hot,c_cold,hotcold]=func_hotcold(whites)
if nargin<1
    whites = ones(16,3);
end
c_hot = flipud(colormap(gca,hot));
c_hot = c_hot(1:56,:); % remove very dark colormaps
c_cold = colormap(gca,cold);
c_cold = c_cold(9:64,:); % remove very dark colormaps
hotcold = [c_cold; whites; c_hot];