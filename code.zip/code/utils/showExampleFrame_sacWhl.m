function showExampleFrame_sacWhl(animals_all,aligned_frames,areacontours,iFrame,ilag,timebins,lags,h)

% 1. iAnimal runs from 1 to 5
% 2. aligned_frames can be filtered or unfiltered
% NOTE that usually filtering of aligned_frames is in lag-lag space, not
% the space of the cortical surface, so additional filtering may be
% necessary



%best_animals = [15352, 16032, 15301, 15309, 15312];

% aligned_frames can have either all animals, or "best animals" only:
assert(numel(animals_all)==size(aligned_frames{1},4));

animal_ids=1:length(animals_all);

if nargin<8,
    figure;
    h=gca;
end
if nargin<4,
    iFrame = 4;
    ilag = 3;
end

t0=10;
filtersize = 20;

for i = 1:length(animal_ids)
    this = squeeze(aligned_frames{ilag}(:,:,iFrame,animal_ids(i)));
    this(this==0)=nan;
    zscores(:,:,i) = this./nanstd(this(:));
end

%nanmask = isnan(squeeze(mean(zscores(:,:,:),3)));
nanmask = sum(~isnan(zscores),3) < (size(zscores,3)-2);
alphadata = ones(size(zscores,1),size(zscores,2));
alphadata(nanmask) = 0.2;
zscores_mean = squeeze(nanmean(zscores,3)); 
zscores_mean_filt = filter2(ones(filtersize)*1/filtersize^2,zscores_mean);

% uncomment for unfiletered:
%show_fig(h,zscores_mean,alphadata,timebins,iFrame,t0,lags,ilag,areacontours);
figure; h1=gca;
show_fig(h1,zscores_mean_filt,alphadata,timebins,iFrame,t0,lags,ilag,areacontours);
contour(zscores_mean_filt, [-2.05 -2.05], 'k')

function show_fig(h,zscores,alphadata,timebins,iFrame,t0,lags,ilag,areacontours)
    axes(h), imagesc(zscores,'AlphaData',alphadata);
    set(gca,'XLim',[50 190],'YLim',[40 180],'XTick',[],'YTick',[]);
    colormap redblue; axis square; colorbar
    title({['avg of z-scores of excitatory animals'],...
        [num2str(0.1*(timebins(iFrame)-t0)) 's from saccade'],...
        [num2str(0.1*(timebins(iFrame)-t0+lags(ilag))) 's from body mvt']});
    set(gcf,'Position',[71   202   414   364],'Color',[1 1 1])

    for j = 1:length(areacontours)
        hold on
        plot(areacontours{j,1},areacontours{j,2},'k')
    end