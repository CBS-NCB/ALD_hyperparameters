function krnf = krnfilt(krn,xdim,ydim)

% krn is a structure with {i} corresponding to an animal; e.g. krn_masked

if nargin<2,
    xdim=15; ydim=15;
end

for iAnimal = 1:length(krn)
    nTiles = size(krn{iAnimal},1);
    krn_this = reshape(krn{iAnimal},nTiles,xdim,ydim);
    
    for iTile = 1:nTiles
        krnf{iAnimal}(:,:,iTile) = filter2(ones(3)*1/9,squeeze(krn_this(iTile,:,:)));
    end
end