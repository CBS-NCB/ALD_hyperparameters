% clean code for
% see explore_M_data_progression.m for the original code


%% 1. prepare data: load the values fitted by HB (on 5 separate accounts)

load('hb_10_20_10_fixed_all_but_M.mat')
tbl_n{1} = tbl;
kLSM_all_1 = kLSM_all;

load('hb_10_20_5_fixed_all_but_M_2.mat')
tbl_n{2} = tbl;
kLSM_all_2 = kLSM_all;

load('hb_10_20_10_fixed_all_but_M_3.mat')
tbl_n{3} = tbl;
kLSM_all_3 = kLSM_all;

load('hb_10_20_10_fixed_all_but_M_4.mat')
tbl_n{4} = tbl;
kLSM_all_4 = kLSM_all;

load('hb_10_20_10_fixed_all_but_M_5.mat')
tbl_n{5} = tbl;
kLSM_all_5 = kLSM_all;
% 

tbl_clean = [];
max_tbl = 0;
for i = 1:5,
    first_zero = find(tbl_n{i}(:,1)==0,1,'first');
    if ~isempty(first_zero)
        tbl_n{i} = tbl_n{i}(1:first_zero-1,:);
    end
    if i>1,
        tbl_n{i}(:,1) = tbl_n{i}(:,1) + max_tbl;
    end
    max_tbl = max(tbl_n{i}(:,1));
end

tbl_clean = cat(1,tbl_n{:});
tbl=tbl_clean;


%% 2. prepare data: create an auxiliary index

kLSM_all = cat(1,kLSM_all_1, kLSM_all_2, kLSM_all_3, kLSM_all_4, kLSM_all_5);

assert(tbl_clean(end,1) == size(kLSM_all,1));

% create an index matrix, useful to find what iBoot/iAn/iTr a trial has
kLSM_trial_ids = zeros(size(kLSM_all,1), size(kLSM_all,2), size(kLSM_all,3) );
ind=1;
for i = 1:size(kLSM_all,1)
    for j = 1:size(kLSM_all,2)
        for k = 1:size(kLSM_all,3)
            kLSM_trial_ids(i,j,k) = ind;
            ind = ind+1;
        end
    end
end

% create a column of "absolute" indices in the table before the data is cleaned
tbl = [tbl, reshape(1:numel(kLSM_trial_ids),[],1)];

%% 3. prepare data: remove outlier values; compute ALD parameters for every animal (M's are animal average; others are population average)

tbl_clean =[];

unqan = unique( tbl(:,3) );
for i = 1:length(unqan),
    tbl_an = tbl(tbl(:,3) == unqan(i), :);
    
    [out,i_excl] = rmoutliers(tbl_an(:,5:8));
    tbl_an(i_excl,:) = [];
    
    tbl_clean = [tbl_clean; tbl_an];
end

tbl = tbl_clean;

% calc "prs" for thetaF:
for i = 1:length(unqan),
    prs(i,:) = [0.001 mean(tbl( tbl(:,3) == unqan(i) , [5 6 7 10 11 12]), 1 )];
end

%% prepare data: compute average kernel from all bootstraps

for iAn = 1:length(unqan),
    this_animal = unqan(iAn);
    
    nrows = sum(tbl(:,3) == this_animal);
    kern_sc = zeros( nrows, 576);

    tbl_this = tbl(tbl(:,3) == this_animal,:);

    for iRow = 1:nrows,
        iBoot = tbl_this(iRow,1);
        iAn_order = tbl_this(iRow,2);
        iBoot_tr = tbl_this(iRow,4);
        kern_sc(iRow,:) = kLSM_all(iBoot,iAn_order,iBoot_tr,:);
    end
    
    kern_mean(iAn,:,:) = reshape( mean(kern_sc,1), 24, 24);
end

% compute kernel ffts and order by increasing M
[~,i_order] = sort(prs(:,2));

for iAn = 1:5,    
    this_kern = squeeze(kern_mean(i_order(iAn),:,:));
    all_ffts_inorder(iAn,:,:) = fftshift(fft2( this_kern  ));% no abs
end

%% Fig4a,b hybrid kernels

diag_range=8;

hybrid_1 = squeeze( all_ffts_inorder(1,:,:) + all_ffts_inorder(2,:,:) );
hybrid_2 = squeeze( all_ffts_inorder(4,:,:) + all_ffts_inorder(5,:,:) );

kernel_hybrid_1 = ifft2(ifftshift(  hybrid_1 ));
kernel_hybrid_2 = ifft2(ifftshift(  hybrid_2 ));

kernel_hybrid_1( abs(kernel_hybrid_1)< 1e-15) = nan; % zero-filled missing values
kernel_hybrid_2( abs(kernel_hybrid_2)< 1e-15) = nan;


figure,
set(gcf,'Position',[ 203         137        1411         806], 'Color',[1 1 1])

subplot(3,4,1);
kernel_img_1 = fliplr(flipud(kernel_hybrid_1));
imagesc(kernel_img_1, 'alphaData', ~isnan(kernel_img_1) );
formatAxes_krn('ifft of avg fft of 2 mice with low pCV; "thick" ');

subplot(3,4,2);
kernel_img_2 = fliplr(flipud(kernel_hybrid_2));
imagesc(kernel_img_2, 'alphaData', ~isnan(kernel_img_2));
formatAxes_krn('ifft of avg of fft of 2 mice with high pCV; "thin" ');


%% Fig 4c. compute and plot variation along the diagonals for hybrid 1 and hybrid 2

for ndiags = 0:23,

    stddiag1 = zeros(2*ndiags+1,1);
    stddiag2 = zeros(2*ndiags+1,1);

    for i = -ndiags:ndiags,
        this_diag = nanstd(diag(kernel_hybrid_1, i));
        stddiag1(i+ndiags+1) = this_diag;
        this_diag = nanstd(diag(kernel_hybrid_2, i));
        stddiag2(i+ndiags+1) = this_diag;
    end

    [h_std,p_std(ndiags+1)]=ttest2(stddiag1, stddiag2);
end


% variation in central ndiags:
ndiags=11; % up to 1.0s rel. lag

stddiag1 = zeros(2*ndiags+1,1);
stddiag2 = zeros(2*ndiags+1,1);

for i = -ndiags:ndiags,
    this_diag = nanstd(diag(kernel_hybrid_1, i));
    stddiag1(i+ndiags+1) = this_diag;
    this_diag = nanstd(diag(kernel_hybrid_2, i));
    stddiag2(i+ndiags+1) = this_diag;
end

subplot(3,4,3), histogram(stddiag1,10); 
hold on, histogram(stddiag2, 10);
title('std(diag), high-M(r) and low-M(b) mice')
xlabel('std')
ylabel('ndiagonals');
set(gca,'TickDir','out');
box off

[h,p] = ttest(stddiag1, stddiag2);
disp([ 'p-value of the ttest ' num2str(p) ]);

%% 
%% Fig4d. Manipulation of the kernel by widening the fft


load('fittingResult.mat')
load('colormap_fig4.mat','cmap');

animal_id = 1;

kernel = fliplr(flipud(reshape(resultFitting(animal_id).kRidge,24,24)));
kernel2DFFT = abs(fftshift(fft2(kernel)));
kernel2DFFTangle = angle(fftshift(fft2(kernel)));

antiDiagonals = zeros(1,size(kernel2DFFT,1));

for ii=1:size(kernel2DFFT,1)
    for kk=1:ii
        antiDiagonals(ii)=antiDiagonals(ii)+kernel2DFFT(ii-kk+1,kk);
    end
end

% modulation using a logn-like profile
logn_modulator = 1 + 3*lognpdf( 0.1*(0:1:11) );
logn_modulator = [logn_modulator fliplr( logn_modulator )];

modulator = zeros(24,24);
for ii=1:length(logn_modulator)
    for kk=1:ii
        modulator(ii-kk+1,kk)=logn_modulator(ii);
    end
end
modulator = modulator + fliplr(flipud(modulator)) - fliplr(eye(length(logn_modulator)));

% add centering window around fft origin
[x,y] = meshgrid(-1.2:0.1:1.1,-1.2:0.1:1.1);
centermod = x.^2 + y.^2;
centermod = 1./(1+centermod);
lognK_center = kernel2DFFT.*centermod .* modulator ;
lognK_center_complex = complex(lognK_center.*cos(kernel2DFFTangle),lognK_center.*sin(kernel2DFFTangle));

figure,
subplot(1,5,1)
imagesc(kernel)
formatAxes_krn('Original Kernel')
caxis([-0.04 0.04])

subplot(1,5,2)
imagesc(kernel2DFFT)
formatAxes_fft('power 2DFFT original Kernel')

subplot(1,5,3); 
imagesc(centermod .* modulator)
formatAxes_fft('windowed modulation profile');
colormap(gca,cmap); 
caxis auto

subplot(1,5,4); 
imagesc(lognK_center)
formatAxes_fft('modulated+windowed spectrum');

subplot(1,5,5)
imagesc(ifft2(ifftshift(lognK_center_complex), 'symmetric'))
formatAxes_krn('ifft of modulated and windowed spectrum');
caxis([-0.04 0.04])

set(gcf,'Color',[1 1 1]);
set(gcf,'Position',[96         529        1653         393]);


%% 

function formatAxes_krn(title_str)
    load('colormap_fig4.mat','cmap');
    title(title_str); 
    set(gca,'XTick',4:5:20,'XTickLabels',{'0','0.5','1.0','1.5'});
    set(gca,'YTick',4:5:20,'YTickLabels',{'0','0.5','1.0','1.5'});
    xlabel('lag wrt wheel');
    ylabel('lag wrt saccade');
    colormap(gca,cmap);
    caxis([-0.03 0.03])
    axis image
    colorbar
    set(gca,'TickDir','out');
    xlabel('Lag w.r. to body mvt, s');
    ylabel('Lag w.r. to saccade, s');
end

function formatAxes_fft(title_str)

    nbins = 24;
    fs = 10;
    dt = 0.1;
    fmax = 1/(2*dt);
    df = fmax/(nbins/2);
    fcoord = -fs/2:df:fs/2;
    fcoord = fcoord(1:end-1);
    labels=mat2cell(fcoord,1,ones(24,1));
    labels=cellfun(@num2str, labels, 'UniformOutput', false);

    xlabels = [5 13 21];
    labels = labels(xlabels);
    
    set(gca,'XTick',xlabels,'XTickLabel',labels,'YTick',xlabels,'YTickLabel',labels);
    
    title(title_str)
    axis image
    colorbar
    caxis([0 2.0]);
end
