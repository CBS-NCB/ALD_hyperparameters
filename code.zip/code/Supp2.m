%% all kernels of individual mice

load('tile_ids.mat', 'tile_ids');

animals =  [15098 15100 16032 15352 15312];

animal_ids = find(ismember( tile_ids(:,1), animals' ));

%% 
load('fittingResult.mat', 'resultFitting');

for iAnimal = 1:length(animal_ids),
    iAn = animal_ids(iAnimal);
    kOLS(:,:,iAnimal) = rot90(  reshape( resultFitting( iAn ).kLSM, 24, 24),  2);
    kRidge(:,:,iAnimal) = rot90(  reshape( resultFitting( iAn ).kRidge, 24, 24)  ,2);
end
%% 
figure,
set(gcf,'Position',[ 203         137        1411         806], 'Color',[1 1 1])
load('colormap_fig4.mat','cmap');

for i = 1:5,
    subplot(2,5,i);
    this_ridge = squeeze(kRidge(:,:,i));
    imagesc(this_ridge, 'AlphaData', ~isnan(this_ridge));
    
    axis image;
    caxis([-0.02 0.02]);
    colorbar
    colormap(gca,cmap);
    set(gca,'TickDir','out');
    xlabel('lag rel. to body movement');
    ylabel('lag rel. to saccade');
    set(gca,'XTick',4:5:20,'XTickLabels',{'0','0.5','1.0','1.5'});
    set(gca,'YTick',4:5:20,'YTickLabels',{'0','0.5','1.0','1.5'});
    
    title(num2str(animals(i)));
    % % %
    
    
    subplot(2,5,5+i);
    this_ols = squeeze(kOLS(:,:,i));
    imagesc(this_ols, 'AlphaData', ~isnan(this_ols));

    axis image;
    caxis([-0.02 0.02]);
    colorbar   
    colormap(gca,cmap);
    set(gca,'TickDir','out');
    xlabel('lag rel. to body movement');
    ylabel('lag rel. to saccade');    
    set(gca,'XTick',4:5:20,'XTickLabels',{'0','0.5','1.0','1.5'});
    set(gca,'YTick',4:5:20,'YTickLabels',{'0','0.5','1.0','1.5'});
    
    title(num2str(animals(i)));    


end


%func_saveFig('\\172.17.150.7\data\Personal\Andrea intern\final Code Interaction Kernel\figures\',[],150,[],'supp_kernels',1,1,1);
