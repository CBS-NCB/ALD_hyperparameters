% Figure 1

% 1. psychometric curves
% 2. average activation maps

data_root = '..\data';
code_root = '..\code';

%% 1. Fig1b: psychometric curves for all mice 
% these are precalculated (e.g. in Lyamzin et al. 2021)

load(fullfile(data_root,'psychometric_data.mat'),'unqdif','p_psych','p_avg_val');

figure(1),
plot(unqdif,p_psych,'Color',[0.7 0.7 0.7]);
hold on, h=plot(unqdif,p_avg_val,'k');
h.LineWidth = 2;

set(gcf,'Position',[613   614   269   343]);
set(gca,'XLim',[-90 90],'YLim',[0 1]);
set(gca,'XTick',-90:30:90,'YTick',0:0.25:1);
set(gca,'TickDir','out','box','off');

xlabel('\Delta\theta');
ylabel('prob. choose right');

%% 2. average activation maps and time trace
%% load stimulus kernels

% t in time bins, 10 Hz sampling
t_peak = 13; % 200ms after stim onset
t_stim_0 = 10; % 0ms, stim onset

% tile of stim peak response: animal_id tile_id
tile_stim =  [15098 126;15100 139; 16032 114; 15352 127; 15312 140];

for i = 1:size(tile_stim,1),
    
    mouse_id = tile_stim(i,1);
    tile_id = tile_stim(i,2);
    
    % load ridge-regression stimulus kernel
    load(fullfile(data_root, ['m' num2str( mouse_id ) '_model_evk_ac_withTensors05.mat']),'model_evk');
    stim_kern(i,:,:) = flipud( model_evk.regr.kRidge_evk );
        
    % peak response with f0-correction:
    stim_kern(stim_kern==0) = nan;
    normalize_to(i) = stim_kern(i,t_peak, tile_id) - stim_kern(i,t_stim_0, tile_id);
    stim_kern_norm(i,:,:) = (stim_kern(i,:,:)- stim_kern(i,t_stim_0, tile_id)) / normalize_to(i) ;
    stim_profile(i,:) = stim_kern_norm(i,:,tile_id);
end

%% Fig1c(a) align activation maps across animals and show population mean

container = nan(251,251);
%load coordinates for map alignment across mice
load(fullfile(data_root,'com.mat'),'cdat');
load(fullfile(data_root,'final.mat'),'fdat','pdat');

mouse_ids = tile_stim(:,1);

for i = 1:length(mouse_ids),
    
    load(fullfile(data_root,['m' num2str( mouse_ids(i)) '_model_evk_ac_withTensors05.mat']),'model_evk');
    maps(i,:,:)=alignPredictedTensors(container, mouse_ids(i), squeeze(stim_kern_norm(i,t_peak,:)), model_evk, cdat, fdat);
    
end
maps(maps==0) = nan;% out of frame pixels

load(fullfile(data_root,'activation_map_mask.mat'),'bw');
areacontours=getAverageAreaContours;

meanmap = squeeze(nanmean(maps));
meanmap = meanmap .* bw;
meanmap(meanmap==0) = nan;
filtersize = 20;
flt = ones(filtersize)*1/filtersize^2;
meanmap_filt = nanconv(meanmap, flt);
figure, imagesc(meanmap_filt)

hold on,
for j = 1:length(areacontours)
    hold on
    plot(areacontours{j,1},areacontours{j,2},'k')
end
axis image

set(gca,'XLim',[40 200], 'YLim',[30 190]);
axis off;
title('stim-on response at peak (t=200ms)');
set(gcf,'Color',[1 1 1]);

load('colormap_fig1.mat','colormap_fig1');
colormap(colormap_fig1);
caxis([-0.15 0.8])
colorbar

%% Fig1d(a) plot stim time trace

time = -1:0.1:2.0;
stim_bins = 10:31;%originally: 10:20; % from onset to +1.0s
stim_plot = stim_profile(:,stim_bins) - stim_profile(:,t_stim_0);
out=func_calc_CI(stim_plot,0.05);

figure,
shadedErrorBar( time(stim_bins), out.mu, out.CI(1,:),'k', 0.2);
set(gca,'TickDir','out');
set(gcf,'Color',[1 1 1]);
title('stim-on at stim ROI, norm to t=0.2s');
xlabel('time,s');
ylabel('dF/F normalized');
set(gcf,'Position',[680   583   297   395]);
set(gca,'XLim',[-0.1 2.0],'YLim',[-3 6]);

%% saccade and body movement kernels: load and align

t_peak_eye = 18; % inverted time in the kernels; 6-th bin of the kernel (200ms after onset) 
t_peak_whl = 16; % 8-th bin of the kernel (400ms after onset)
eye_tiles = [16032 124; 15352 137; 15312 137; 15098 164; 15100 122];
whl_tiles = [16032 124; 15352 31; 15312 46; 15098 164; 15100 58];

container = nan(251,251);
load(fullfile(data_root,'com.mat'),'cdat');
load(fullfile(data_root,'final.mat'),'fdat','pdat');

for i = 1:length(mouse_ids),
    load(fullfile(data_root,['m' num2str( mouse_ids(i) ) '_model_s_w05_ac.mat']),'model_s_w');
    
    eye_kern(i,:,:) = model_s_w.regr.kRidge_e';
    whl_kern(i,:,:) = model_s_w.regr.kRidge_w';

    tile_id_eye = eye_tiles(eye_tiles(:,1)==mouse_ids(i),2);
    eye_kern_norm(i,:,:) = (eye_kern(i,:,:) - eye_kern(i,end,:))/ normalize_to(i); %eye_kern(i, t_peak_eye, tile_id_eye) ;
    eye_profile(i,:) = fliplr( eye_kern_norm(i,:,tile_id_eye) );
    
    tile_id_whl = whl_tiles(  whl_tiles(:,1) == mouse_ids(i),2);
    whl_kern_norm(i,:,:) = (whl_kern(i,:,:) - whl_kern(i,end,:))/ normalize_to(i); % / whl_kern(i, t_peak_whl, tile_id_whl);
    whl_profile(i,:) = fliplr( whl_kern_norm(i,:,tile_id_whl) );
    
    maps_eye(i,:,:)=alignPredictedTensors(container, mouse_ids(i) , squeeze(eye_kern_norm(i,t_peak_eye,:)) ,model_s_w, cdat, fdat);
    maps_whl(i,:,:)=alignPredictedTensors(container, mouse_ids(i) , squeeze(whl_kern_norm(i,t_peak_eye,:)) ,model_s_w, cdat, fdat);
end

%% Fig1c,d: show activation maps and time profiles

maps_eye(maps_eye==0) = nan;
meanmap_e = squeeze(nanmean(maps_eye));
meanmap_e = meanmap_e .* bw;
meanmap_e(meanmap_e==0) = nan;
meanmap_e_filt = nanconv(meanmap_e, flt);
figure, imagesc(meanmap_e_filt)

hold on, 
for j = 1:length(areacontours)
    hold on
    plot(areacontours{j,1},areacontours{j,2},'k')
end

axis image
set(gca,'XLim',[40 200], 'YLim',[30 190]);
axis off;
title('saccade response at peak (t=200ms)');
set(gcf,'Color',[1 1 1]);
colorbar
colormap(colormap_fig1)

% % %

maps_whl(maps_whl==0) = nan;
meanmap_w = squeeze(nanmean(maps_whl));
meanmap_w = meanmap_w .* bw;

meanmap_w(meanmap_w==0) = nan;
meanmap_w_filt = nanconv(meanmap_w, flt);
figure, imagesc(meanmap_w_filt)

hold on, 
for j = 1:length(areacontours)
    hold on
    plot(areacontours{j,1},areacontours{j,2},'k')
end

axis image
set(gca,'XLim',[40 200], 'YLim',[30 190]);
axis off;
title('wheel response at peak (t=400ms)');
set(gcf,'Color',[1 1 1]);
caxis([0.25 0.82])
colorbar
colormap(colormap_fig1)

% % %

t0=1;
time = -0.3:0.1:2.0;
eye_plot = eye_profile - eye_profile(:,t0);
out=func_calc_CI(eye_plot,0.05);

figure,
shadedErrorBar( time, out.mu, out.CI(1,:),'k', 0.5);
set(gca,'TickDir','out');
set(gcf,'Color',[1 1 1]);
title('saccade at saccade ROI, norm to stim.ampl.');% t=0.2s');
xlabel('time,s');
ylabel('dF/F normalized');
set(gcf,'Position',[680   583   297   395]);
set(gca,'XLim',[-0.5 2.0],'YLim',[-3 6]);

% % %

t0=1;
time = -0.3:0.1:2.0;
whl_plot = whl_profile - whl_profile(:,t0);
out=func_calc_CI(whl_plot,0.05);

figure,
shadedErrorBar( time, out.mu, out.CI(1,:),'k', 0.5);
set(gca,'TickDir','out');
set(gcf,'Color',[1 1 1]);
title('wheel at wheel ROI, norm to stim.ampl.');% t=0.4s');
xlabel('time,s');
ylabel('dF/F normalized');
set(gcf,'Position',[680   583   297   395]);
set(gca,'XLim',[-0.5 2.0],'YLim',[-3 6]);

%% Fig 1e

figGLMsequential_short();

set(gca,'TickDir','out');
set(gcf,'Position',[680   658   295   320]);
